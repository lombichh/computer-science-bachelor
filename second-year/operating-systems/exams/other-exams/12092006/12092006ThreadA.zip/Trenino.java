
public class Trenino{

private int current_ch_queue=0; 
private int current_ad_queue=0; 
private int current_ch_served=0;
private int current_ad_served=0;
private int in_service=0;
private int out_service=0;
private int PMAX=3;


public synchronized int acquire_adult(int id){
	int my_pos=current_ad_queue;
	current_ad_queue++;
	System.out.println("Thread adult "+id+" entrato in coda");	
	try{
		while(my_pos>current_ad_served || current_ch_queue>current_ch_served || in_service==PMAX){
			wait();
			}
		} catch(InterruptedException e){}
	current_ad_served++;
	in_service++;
	System.out.println("Thread adult "+id+" in servizio");
	notifyAll();		
	/*Questa invocazione serve perche' l'ordine di risveglio dei Thread bloccati non e' certo.
	 *Avendo cioe' il Thread attuale modificato il valore di due variabili condivise (in particolare
	 *della variabile current_ad_served) e' corretto che risvegli tutti i Thread bloccati provocando
	 *un nuovo check delle condizioni.
	 *Per essere piu' chiari, si consideri una coda degli adulti formata dai Thread 38, 26, 12 in quest'ordine
	 *(e si supponga che la coda dei bambini sia vuota).
	 *Si supponga che la JVM svegli prima il 26, poi il 38, infine il 12. In questo caso il 26 si blocca
	 *per via della politica FIFO, il 38 passa, il 12 si blocca: in realta' con PMAX=3 tutti e tre dovrebbero
	 *entrare in servizio. Con questa invocazione a notifyAll() tutti i processi vengono correttamente svegliati.
	 */
	return in_service;
	
	}

public synchronized int acquire_child(int id){
	int	my_pos=current_ch_queue;
	current_ch_queue++;
	System.out.println("Thread child "+id+" entrato in coda");
	try{
		while(my_pos>current_ch_served || in_service==PMAX ) {
			wait();
			}
		} catch(InterruptedException e){}
	current_ch_served++;			
	in_service++;
	notifyAll();
	/*Questa invocazione serve per i motivi esposti sopra. In aggiunta, in questo caso
	 *il servizio di un Thread child potrebbe sbloccare un Thread adult
	 */
	System.out.println("Thread child "+id+" in servizio");
	return in_service;
	
	}

	
public synchronized void release(int id){
	out_service++;
	System.out.println("Thread "+id+" abbandona la corsa");
	
	/*Ci vorrebbe una notifyAll() anche qui, visto che si e' modificato il 
	 *valore di una variabile condivisa, ma in questo caso e' inutile perche' nessun Thread
	 *puo' essere bloccato a causa del valore di out_service.
	 */
	
	if(out_service==PMAX) {
		System.out.println("Nuova corsa");
		in_service=out_service=0;
		notifyAll();
		}
	}
	
}