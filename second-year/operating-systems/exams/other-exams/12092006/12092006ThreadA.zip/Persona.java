
public class Persona extends Thread {

	Trenino queue;
	boolean child;
	int id;
	
	public Persona(Trenino queue, boolean child, int id){this.queue=queue;this.child=child;this.id=id;}
	
	public void run(){
		if(child)req_child();
		else req_adult();
	 
		}
		
	public void req_child(){
   	    queue.acquire_child(id);
		try{Thread.sleep(10000);}catch(InterruptedException e){}
		queue.release(id);
		}
		
	public void req_adult(){
		queue.acquire_adult(id);
		try{Thread.sleep(10000);}catch(InterruptedException e){}
		queue.release(id);
		}
}
