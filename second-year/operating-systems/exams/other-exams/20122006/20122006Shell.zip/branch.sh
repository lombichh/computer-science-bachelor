#!/bin/bash

#test sul numero di argomenti
#NOTA: la protezione di $1 con i doppi apici permette di trattare direttori il cui nome contiene degli spazi

if test $# -ne 1
then
    echo "usage:$0 <dir>"
    exit 1
fi

case "$1" in
    /*) ;;
    *)  echo "$1 is not an absolute directory"
        exit 2;;
    esac
if ! test -d "$1"
then
    echo "$1 is not a valid directory"
    exit 3
fi

appo=~/appoggio.txt
echo '0' > $appo

PATH=$PATH:`pwd`
branch_rec.sh "$1"

cat $appo

rm $appo