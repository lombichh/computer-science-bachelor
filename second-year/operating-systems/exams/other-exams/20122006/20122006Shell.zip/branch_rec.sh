#!/bin/bash

#mi sposto nel direttorio passato come argomento
appo=~/appoggio.txt
cd "$1"


branch=`ls -l|grep ^d|wc -l`
cur=`cat $appo | head -n 1`

if test $branch -eq $cur
then
    echo `pwd` >> $appo
elif test $branch -gt $cur
then
    echo $branch> $appo
    echo `pwd` >> $appo
fi

for f in *
do
    #se il file corrente e' un link, lo salto 
    if test -h "$f"
    then
        continue			 
    #se il file corrente e' un direttorio, devo invocarmi ricorsivamente
    elif test -d "$f"
    then
        $0 "$f"
    fi
done
exit 0
