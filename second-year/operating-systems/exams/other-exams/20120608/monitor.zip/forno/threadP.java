//
//  threadP.java
//  forno
//
//  Created by anna ciampolini on 13/06/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

import java.util.Random;

public class threadP extends Thread
{	
	private monitor FORNO;
	public int DEST;
		
	public threadP( monitor Mon,  int dest)
	{	
		this.FORNO = Mon;
		this.DEST = dest;
	}

	public void run()
	{ 	
		Random rand = new Random();
		try
		{ 	
			sleep( rand.nextInt(15000) );
						
			FORNO.entraP(DEST);
			sleep(rand.nextInt(3000));
			FORNO.esceP();
			
						
		}
		catch(InterruptedException e)
		{	
		}
		
		

	}
	
	
	
}
