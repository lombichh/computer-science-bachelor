//
//  forno.java
//  forno
//
//  Created by anna ciampolini on 13/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//
import java.util.*;

 import java.util.Random;
//import java.util.concurrent.*;

public class forno {
	   
    public static void main(String[] args) {
      
    
  
      System.out.println("esercizio compito A - 8 giugno 2012\n");

       	int i;
		        
        monitor mioforno = new monitor();
		Random rand = new Random();
		threadF []TF = new threadF[20];
		threadP []TP = new threadP[20];

		for( i=0 ; i<20 ; i++)
			TF[i] = new threadF(mioforno,  rand.nextInt(2) );
		for( i=0 ; i<20 ; i++)
			TP[i] = new threadP(mioforno,  rand.nextInt(2) );
		
	for( i=0 ; i<20 ; i++)
			TF[i].start();
		for( i=0 ; i<20 ; i++)
			TP[i].start();

	  
    }
}