public class Launcher {

	public static void main(String[] args){
		
		Cassa[] casse = new Cassa[]{new Cassa(1),new Cassa(2),new Cassa(3),new Cassa(4)};

		Cliente[] clienti = new Cliente[10];
		//inizializzazione clienti
		for (int i=0 ; i<10; i++){
			clienti[i]= new Cliente(casse,"cliente_"+i);
		}

		//lancio clienti
		for (int i=0 ; i<10; i++){
			clienti[i].start();
		}

	}

}
