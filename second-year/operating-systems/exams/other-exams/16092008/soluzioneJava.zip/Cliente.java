public class Cliente extends Thread {
	public static final int DELAY = 2000;
	public static final int	MAX_QUEUED_TIME = 5000;
	Cassa[] queues;
	String nomeCliente;
	public Cliente(Cassa[] queues, String nomeCliente){
		this.queues=queues;
		this.nomeCliente=nomeCliente;
	}
	
	public void run(){
		int i = -1; 
		int position = 0;
		do {
			//ad ogni passo della iterazione, se ci sono ancora code disponibili, mi sposto nella successiva
			//altrimenti rimango nell'ultima coda disponibile
			if ( i < queues.length )
				i++; 
			if (queues[i] != null){
				position = queues[i].acquire();
				System.out.println("Cliente "+nomeCliente+ "- risultato aquire(): "+position);
				//si consiglia di adottare la convenzione seguente relativa al metodo aquire:
				//  -) se il thread ha trascorso più di MAX_QUEUED_TIME secondi, ritorna la posizione di 					//	ingresso in coda
				//  -) se il thread ha trascorso MENO di MAX_QUEUED_TIME secondi, ritorna -1
				
				//il cliente ha aspettato in coda più di MAX_QUEUED_TIME E ci sono ancora code disponibili
				//--> abbandona la coda corrente e al prossimo passo di iterazione entrerà nella successiva
				if( position >= 0 && i < queues.length )
					queues[i].abandon(position);
			}
		}
		while( position >= 0 );

		try{Thread.sleep(DELAY);}catch(InterruptedException e){}
		System.out.println("Cliente "+nomeCliente+ "- release()-ing ... ");
		queues[i].release();
	}
}
