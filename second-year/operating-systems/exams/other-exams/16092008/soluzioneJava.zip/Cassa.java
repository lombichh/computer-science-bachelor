public class Cassa {


private int current_served=0;  //attualmente servito
private int current_queue=0; //primo posto libero alla fine della coda

private int idcassa;
public Cassa (int idcassa){
	this.idcassa = idcassa;
}

public synchronized int acquire(){

	int my_pos=current_queue;
	current_queue++;

	long queue_entrance_time = new java.util.Date().getTime();

	try{
		while(my_pos>current_served &&
			new java.util.Date().getTime() - queue_entrance_time < Cliente.MAX_QUEUED_TIME  ){
			wait();
		}
	} catch(InterruptedException e){}

	long queued_time = new java.util.Date().getTime() - queue_entrance_time ;

	if ( queued_time >= Cliente.MAX_QUEUED_TIME ){
		System.out.println("Utente "+Thread.currentThread().getName()+": tempo massimo trascorso in cassa  "+idcassa);
		return my_pos;
	}
	else{
		System.out.println("Utente "+Thread.currentThread().getName()+": entrato in coda nella cassa "+idcassa);
		return -1;
	}

}

public synchronized void release(){
	System.out.println("Utente "+Thread.currentThread().getName()+": servito in cassa "+idcassa);
	current_served++;
	notifyAll();
}

public synchronized void abandon(int position){
	System.out.println("Utente "+Thread.currentThread().getName()+": tenta di abbandonare cassa "+idcassa);
	try{
		while(position != current_queue - 1){
			wait();
		}
	} 
	catch(InterruptedException e){}
	System.out.println("Utente "+Thread.currentThread().getName()+": ABBANDONA cassa "+idcassa+" posizione "+position);
	current_queue --;
	notifyAll();

}

}
