#!/bin/sh

if test $# -lt 2
then    
   echo "usage:$0 <destinationDir> <targetDir1> ... <targetDirN>"    
   exit 1
fi

for i in $*
do
	case $i in    
	/*) ;;    
	*)  echo "$i is not an absolute directory"        	
	    exit 2;;
	esac
	if ! test -d "$i"
	then    
		echo "$i is not a valid directory"
		exit 3
	fi

done

destination=$1
shift

oldpath=$PATH
PATH=$PATH:`pwd`

for i in $*
do
   linkExecutables_rec.sh "$destination" "$i"
done

PATH=$oldpath
