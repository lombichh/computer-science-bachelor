#!/bin/sh
#$1: cartella di destinazione dei link 
#$2: cartella sulla quale andare in ricorsione

cd "$2" 

for f in *
do

	if test -d "$f"; then
		$0 "$1" "$2"/"$f"
	elif test -x "$f"; then
		if test -h "$f"; then #il file corrente è eseguibile ed e' un link 
			cp -d "$2"/"$f" "$1" 
			
			#Oppure:
			#targetFile=`ls -l "$2"/"$f" | cut -d '>' -f 2 | cut -d ' ' -f 2 `
			#ln -s "$targetFile" "$1"/"$f"
			#echo Link eseguibile: "$f"
			
		elif test -f "$f"; then #il file corrente è eseguibile ed e' un file regolare
			ln -s "$2"/"$f" "$1"/"$f"
			echo File eseguibile: "$f"			
		fi
	fi

done
