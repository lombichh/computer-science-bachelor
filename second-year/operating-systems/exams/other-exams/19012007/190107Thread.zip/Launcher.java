
public class Launcher {

public static void main(String[] args){
	Officina queue=new Officina();
	Vettura r1=new Vettura(queue,1);
	Vettura r2=new Vettura(queue,2);
	Vettura r3=new Vettura(queue,3);
	Vettura r4=new Vettura(queue,4);
	Vettura r5=new Vettura(queue,5);
	Vettura r6=new Vettura(queue,6);
	Vettura r7=new Vettura(queue,7);
	Vettura r8=new Vettura(queue,8);
	Vettura r9=new Vettura(queue,9);
	
	r1.start(); //Ovviamente la prima entra nella risorsa senza
				//seguire la politica di gestione della coda 
				//(la prima non entra in alcuna coda)
	r2.start();
	r3.start();
	//try{Thread.sleep(3000);}catch(InterruptedException e){}
	r4.start();
	r5.start();
	r6.start();
	r7.start();
	r8.start();
	r9.start();
	}

}
