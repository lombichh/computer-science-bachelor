
/*Questa classe gestisce la coda delle auto in attesa di essere
 *riparate fuori dalla officina*/
public class Officina{

private int current_pos=0;
private int in_service=0;
private int PMAX=5;

public synchronized int arrivo(int id){
	int my_pos;
	current_pos++;
	//Memorizzazione del proprio stato nella eventuale coda
	my_pos=current_pos;
	//Verifica del raggiungimento del limite massimo della coda
	if(current_pos>PMAX) {
			current_pos--;
			return 0;
			}
	System.out.println("Thread "+id+" entrato");	
	try{
		while(in_service==1 || current_pos!=(my_pos)){
			wait();
			}
		} catch(InterruptedException e){}
	//Occupazione della risorsa (tramite il flag in_service) e liberazione del 
	//proprio posto in coda
	in_service=1;
	current_pos--;
	System.out.println("Thread "+id+" in servizio");
	return in_service;
}


	
public synchronized void uscita(int id){
	//Liberazione della risorsa e notifica
	in_service=0;
	System.out.println("Thread "+id+" libera");
	notifyAll();
	}
	
}