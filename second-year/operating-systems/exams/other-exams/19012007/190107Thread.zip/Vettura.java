
public class Vettura extends Thread {

	Officina queue;
	int id;
	
	public Vettura(Officina queue, int id){this.queue=queue;this.id=id;}
	
	public void run(){
		  int accettata=queue.arrivo(id);
		  if(accettata==0) {System.out.println("Vettura "+id+" non accettata");}
		  else{
			   try{Thread.sleep(2000);}catch(InterruptedException e){}
			   queue.uscita(id);
			  }
		}
		

		
}
