#!/bin/bash

if test $# -lt 3
then
	echo "usage: $0 <sourceDir> <targetDir> <key1> ... <keyN>"
	exit 1
fi

sourceDir=$1

if ! test -d "$sourceDir"
then
	echo "$sourceDir is not a valid directory"
	exit 2
fi

targetDir=$2

case $2 in
	/*);;
	*)
		echo "$targetDir is not an absolute directory name"
		exit 3;;
esac


if test -d "$targetDir"
then
	echo "$targetDir exists!"
	exit 4
fi


shift
shift

for i in $*
do
	case $i in
		[a-z]);;
		*) 
			echo "Param $i is not a lowercase letter"
			exit 5;;
	esac
done

PATH=$PATH:`pwd`
arch_recursive.sh $sourceDir $targetDir $*

if test -d $targetDir
then
	ls -Rl $targetDir
else
	echo No file archived
fi





