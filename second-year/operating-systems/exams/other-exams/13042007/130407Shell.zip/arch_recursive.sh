#!/bin/bash

sourceDir=$1
targetDir=$2
shift
shift



cd "$sourceDir"

for file in *
do
	
	if test -h "$file"
	then
		continue
	elif test -d "$file"
	then
		$0 "$file" $targetDir $*
	else
		for i in $*
		do
			case $file in
				$i*) 
					if ! test -d $targetDir
					then
						mkdir "$targetDir"
					fi
					if ! test -d "$targetDir"/$i
					then
						mkdir "$targetDir"/$i
					fi
					cp "$file" "$targetDir/$i/$file";;
				*);;
			esac
		done
	fi
done







