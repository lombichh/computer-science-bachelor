
public class Launcher {

public static void main(String[] args){
	Proiezione queue=new Proiezione();
	Persona r1=new Persona(queue,true,1);
	Persona r2=new Persona(queue,false,2);
	Persona r3=new Persona(queue,false,3);
	Persona r4=new Persona(queue,false,4);
	Persona r5=new Persona(queue,false,5);
	Persona r6=new Persona(queue,false,6);
	Persona r7=new Persona(queue,true,7);
	Persona r8=new Persona(queue,false,8);
	Persona r9=new Persona(queue,false,9);
	Persona r10=new Persona(queue,true,10);
	
	r1.start();
	try{Thread.sleep(2000);}catch(InterruptedException e){}
	r2.start();
	r3.start();
	r4.start();
	r5.start();
	r6.start();
	r7.start();
	try{Thread.sleep(8000);}catch(InterruptedException e){}
	r8.start();
	r9.start();
	r10.start();
	}

}
