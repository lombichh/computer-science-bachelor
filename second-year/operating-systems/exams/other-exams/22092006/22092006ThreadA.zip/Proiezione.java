
public class Proiezione{

private int current_ch_queue=0; 
private int current_ad_queue=0; 
private int current_ch_served=0;
private int current_ad_served=0;
private int current_old_served=0;
private int current_old_queue=0;
private int in_service=0;
private int out_service=0;
private int PMAX=5;
private int MAXQUEUE=2;


public synchronized int acquire_adult(int id){
	int my_pos=current_ad_queue;  //Si potrebbe facilmente aggiungere un controllo: se un adulto raggiunge MAXTIME in coda, allora entra in servizio
	current_ad_queue++;
	System.out.println("Thread adult "+id+" entrato in coda");	
	try{
		while(my_pos>current_ad_served || in_service>PMAX-2 ||
				(current_ch_queue-current_ch_served>MAXQUEUE) ||
				(current_ch_queue>current_ch_served && current_ad_queue-current_ad_served<=MAXQUEUE)){
			wait();
			}
		} catch(InterruptedException e){}
	current_ad_served++;
	in_service+=2;
	notifyAll();    //Potrebbe sbloccare un adulto che invece ha ricontrollato la coda
	System.out.println("Thread adult "+id+" in servizio");
	return in_service;
	
	}

public synchronized int acquire_child(int id){
	int	my_pos=current_ch_queue;
	current_ch_queue++;
	System.out.println("Thread child "+id+" entrato in coda");
	try{
		while(my_pos>current_ch_served || in_service>PMAX-1 ||				
				(current_ad_queue-current_ad_served>MAXQUEUE && current_ch_queue-current_ch_served<=MAXQUEUE )){
			wait();
			}
		} catch(InterruptedException e){}
	current_ch_served++;			
	in_service++;
	notifyAll(); 	//Potrebbe sbloccare un adulto che invece ha ricontrollato la coda
	System.out.println("Thread child "+id+" in servizio");
	return in_service;
	
	}

	
public synchronized void release(boolean adult, int id){
	if(adult)out_service+=2;
	else out_service++;//Attenzione non e' accettabile una situazione in cui in_service viene decrementato qui
	if(out_service==PMAX) {
		System.out.println("Nuova corsa");
		in_service=out_service=0; //attenzione in_service deve essere azzerato qui!								
		notifyAll();
		}
	}
	
}