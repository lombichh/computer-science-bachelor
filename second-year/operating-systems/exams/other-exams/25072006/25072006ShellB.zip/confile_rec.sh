#!/bin/bash

#NOTA: la protezione di $1, $2 e $f con i doppi apici permette di trattare direttori, pattern e file contenenti degli spazi

#mi sposto nel direttorio passato come argomento
appo=~/report.txt
cd "$2"

if test -r "$1"
then
    value=`cat "$1" | wc -m`
    echo "$value `pwd`/$1" >> $appo
    exit 0
fi

for f in *
do
    #se il file corrente e' un link, lo salto 
    if test -h "$f"
    then
        continue			 
   
    #se il file corrente e' un direttorio, devo invocarmi ricorsivamente
    elif test -d "$f"
    then
        $0 "$1" "$f"
    fi
done
exit 0
