#!/bin/bash

#test sul numero di argomenti
#NOTA: la protezione di $1 con i doppi apici permette di trattare direttori il cui nome contiene degli spazi

if test $# -lt 2
then
    echo "usage:$0 <file> <dir1> <dir2> ... <dirN>"
    exit 1
fi
file="$1"

shift
for i in $*
do
    case $i in
    /*) ;;
    *)  echo "$i is not an absolute directory"
        exit 3;;
    esac
    if ! test -d "$i"
    then
        echo "$i is not a valid directory"
        exit 4
    fi
done

appo=~/report.txt
> $appo

PATH=$PATH:`pwd`
for dir in $*
do
    confile_rec.sh "$file" "$dir"
done
if test -z "`cat $appo`"
then
    echo $file non trovato in nessun direttorio!
else
    echo VALORE MASSIMO: `cat $appo | sort | tail -n 1`
fi