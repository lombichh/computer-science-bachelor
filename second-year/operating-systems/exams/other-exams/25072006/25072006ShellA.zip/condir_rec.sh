#!/bin/bash

#NOTA: la protezione di $1, $2 e $f con i doppi apici permette di trattare direttori, pattern e file contenenti degli spazi

#mi sposto nel direttorio passato come argomento
appo=~/condir.txt
cd "$1"

#scorro i file del direttorio corrente
new_dir=""
for dir in `cat $appo`
do
    if ! test -d "$dir"
    then
        new_dir="$new_dir $dir"
    fi
done
>$appo
if test -z "$new_dir"
then
    exit 0
else
    echo $new_dir>$appo
fi

for f in *
do
    #se il file corrente e' un link, lo salto 
    if test -h "$f"
    then
        continue			 
   
    #se il file corrente e' un direttorio, devo invocarmi ricorsivamente
    elif test -d "$f"
    then
        $0 "$f"
        if test -z `cat $appo`
        then
            exit 0
        fi
    fi
done
exit 0
