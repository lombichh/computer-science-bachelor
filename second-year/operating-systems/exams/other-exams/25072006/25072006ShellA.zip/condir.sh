#!/bin/bash

#test sul numero di argomenti
#NOTA: la protezione di $1 con i doppi apici permette di trattare direttori il cui nome contiene degli spazi

if test $# -lt 2
then
    echo "usage:$0 <dir> <dir1> <dir2> ... <dirN>"
    exit 1
fi
dir="$1"
case "$dir" in
    /*) ;;
    *)  echo "$dir is not an absolute directory"
        exit 2;;
esac
if ! test -d "$dir"
then
    echo "$dir is not a valid directory"
    exit 3
fi

shift

appo=~/condir.txt

echo $* > $appo
PATH=$PATH:`pwd`
condir_rec.sh "$dir"
if test -z `cat $appo`
then
    echo Tutti i direttori trovati!
else
    echo Direttori rimanenti: `cat $appo`
fi
rm $appo