import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Parco { //MONITOR
	 
	private final static int BA = 0;
	private final static int BG = 1;
	private int MAX;
	private int N;
	private int visitatoriPresenti;
	private int entratiDaNord;
	private int entratiDaSud;
	private Lock lock = new ReentrantLock();
	private Condition[] ingrNord = new Condition[2];
	private int[] sospIngrNord = new int[2];
	private Condition[] ingrSud = new Condition[2];
	private int[] sospIngrSud = new int[2];
	
	public Parco(int max, int n) {
		MAX = max;
		N = n;
		visitatoriPresenti = 0;
		entratiDaNord = 0;
		entratiDaSud = 0;
		for(int i = 0; i < 2; i++){
			ingrNord[i] = lock.newCondition();
			sospIngrNord[i] = 0;
			ingrSud[i] = lock.newCondition();
			sospIngrSud[i] = 0;
		}
	}

	public void entraNord(Visitatore v) throws InterruptedException{
		lock.lock();
		try{
			if(v.getTipoBiglietto() == "BA"){
				while(visitatoriPresenti == MAX || condizione_ingressi("NORD")){
					sospIngrNord[BA]++;
					ingrNord[BA].await();
					sospIngrNord[BA]--;
				}
				entratiDaNord++;
				visitatoriPresenti++;
				System.out.println(v.getName() + " con biglietto BA è entrato da Nord. #visitatoriPresenti = " + visitatoriPresenti + " #entratiDaNord = " + entratiDaNord + " #entratiDaSud = " + entratiDaSud);
				}
			else if(v.getTipoBiglietto() == "BG"){
				while(visitatoriPresenti == MAX || condizione_ingressi("NORD") || sospIngrNord[BA] > 0 ){
					sospIngrNord[BG]++;
					ingrNord[BG].await();
					sospIngrNord[BG]--;
				}
				entratiDaNord++;
				visitatoriPresenti++;
				System.out.println(v.getName() + " con biglietto BG è entrato da Nord. #visitatoriPresenti = " + visitatoriPresenti + " #entratiDaNord = " + entratiDaNord + " #entratiDaSud = " + entratiDaSud);
			}
			if(!condizione_ingressi("SUD") && sospIngrSud[BA] > 0)
				ingrSud[BA].signal();
			else if(!condizione_ingressi("SUD") && sospIngrSud[BA] == 0 && sospIngrSud[BG] > 0)
				ingrSud[BG].signal();
		}
		finally{ lock.unlock(); }
	}
	
	public void entraSud(Visitatore v) throws InterruptedException{
		lock.lock();
		try{
			if(v.getTipoBiglietto() == "BA"){
				while(visitatoriPresenti == MAX || condizione_ingressi("SUD")){
					sospIngrSud[BA]++;
					ingrSud[BA].await();
					sospIngrSud[BA]--;
				}
				entratiDaSud++;
				visitatoriPresenti++;
				System.out.println(v.getName() + " con biglietto BA è entrato da Sud.  #visitatoriPresenti = " + visitatoriPresenti + " #entratiDaNord = " + entratiDaNord + " #entratiDaSud = " + entratiDaSud);
			}
			else if(v.getTipoBiglietto() == "BG"){
				while(visitatoriPresenti == MAX || condizione_ingressi("SUD") || sospIngrSud[BA] > 0 ){
					sospIngrSud[BG]++;
					ingrSud[BG].await();
					sospIngrSud[BG]--;
				}
				entratiDaSud++;
				visitatoriPresenti++;
				System.out.println(v.getName() + " con biglietto BG è entrato da Sud.  #visitatoriPresenti = " + visitatoriPresenti + " #entratiDaNord = " + entratiDaNord + " #entratiDaSud = " + entratiDaSud);
			}
			if(!condizione_ingressi("NORD") && sospIngrNord[BA] > 0)
				ingrNord[BA].signal();
			else if(!condizione_ingressi("NORD") && sospIngrNord[BA] == 0 && sospIngrNord[BG] > 0)
				ingrNord[BG].signal();
		}
		finally{ lock.unlock(); }
	}
	
	public void esce(boolean moneta){
		lock.lock();
		try{
			visitatoriPresenti--;
			if (moneta) // segnalo prima il cancello nord (la scelta viena fatta in modo casuale)
			{	if(sospIngrNord[BA] > 0)			
					ingrNord[BA].signal();			
				else if(sospIngrSud[BA] > 0)		
					ingrSud[BA].signal();
				else if(sospIngrNord[BG] > 0)		
					ingrNord[BG].signal();			
				else if(sospIngrSud[BG] > 0)		
					ingrSud[BG].signal();
			} 
			else	// segnalo prima il cancello sud
			{	if(sospIngrSud[BA] > 0)			
				ingrSud[BA].signal();			
			else if(sospIngrNord[BA] > 0)		
				ingrNord[BA].signal();
			else if(sospIngrSud[BG] > 0)		
				ingrSud[BG].signal();			
			else if(sospIngrNord[BG] > 0)		
				ingrNord[BG].signal();
			}									
			System.out.println("Una persona è uscita. #visitatoriPresenti = " + visitatoriPresenti);
			
		}
		finally{ lock.unlock(); }
	}
	
	private boolean condizione_ingressi(String ingresso){
		if(entratiDaNord + entratiDaSud < N)
			return false;
		if(ingresso == "NORD")
			return entratiDaNord + 1 > N/2 + entratiDaSud;
		else if(ingresso == "SUD")
			return entratiDaSud + 1 > N/2 + entratiDaNord;
		return false;
	}
}
