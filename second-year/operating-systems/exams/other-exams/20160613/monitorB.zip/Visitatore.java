
import java.util.Random;

public class Visitatore extends Thread {

	private Random r;
	private Parco p;
	private String tipoBiglietto;
	
	public Visitatore(Random r, Parco p) {
		this.r = r;
		this.p = p;
		tipoBiglietto = (r.nextBoolean()) ? ("BG") : ("BA");
	}

	public String getTipoBiglietto() {
		return tipoBiglietto;
	}

	public int getTipoBigliettoNumber() {
		if(tipoBiglietto == "BA")
			return 0;
		return 1;
	}
	

	public void run() {
		try{
			
			if(r.nextBoolean())
				p.entraNord(this);
			else
				p.entraSud(this);
			sleep(r.nextInt((tipoBiglietto == "BA") ? (20) : (10)) * 1000); 
			p.esce(r.nextBoolean());
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
}
