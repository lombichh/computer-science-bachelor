
import java.util.Random;

public class esame{

	
	public static void main(String[] args) {
		
		final int MAX = 30;
		final int N = 10;
		final int TOTVIS=50;
		int i;
		
		Parco p = new Parco(MAX, N);
		Random r = new Random(System.currentTimeMillis());				
		Visitatore []v=new Visitatore[TOTVIS];
		
		for (i=0;i<TOTVIS; i++)
			v[i] = new Visitatore(r, p);	
		
		for (i=0;i<TOTVIS; i++)
			v[i].start();
			
		}
}
		


