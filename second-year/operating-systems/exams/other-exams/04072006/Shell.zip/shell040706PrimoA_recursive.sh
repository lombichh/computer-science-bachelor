#!/bin/bash

#NOTARE LA PROTEZIONE DEI PARAMETRI CON I DOPPI APICI:

#mi sposto nel direttorio passato come argomento
cd "$1"

counter=0 #valore massimo corrente

#scorro i file del direttorio corrente
for f in *
do
    #se il file corrente e' un link, lo salto 
    if test -h "$f"
    then
        continue			 
   
    #se il file corrente e' un direttorio, devo invocarmi ricorsivamente
    elif test -d "$f"
    then
        $0 "$f" $2 
    else 
    #se il file corrente � un file leggibile e rispetta il pattern, conto
    if test -r "$f"
        then
            case "$f" in
            *"$2"*) #NOTA: se $2 � assente, coincide con la stringa vuota, quindi il pattern diventa ** ovvero * (fa match qualsiasi file)
                cur=`cat "$f" | wc -l` #cur contiene il numero di righe di $f
                #eventuale sostituzione del massimo corrente
                if test $cur -gt $counter 
                then 
                    counter=$cur 
                fi;;
            esac
        fi
    fi
done
echo massimo numero di righe in $1: $counter
exit 0
