#!/bin/bash

#test sul numero di argomenti
if test $# -lt 1
then
    echo "usage:$0 <dir> [<filter>]"
    exit 1
fi

case $1 in
    /*) ;;
    *)  echo "$1 is not an absolute directory"
        exit 3;;
esac
if ! test -d "$1"
then
    echo "$1 is not a valid directory"
    exit 4
fi

PATH=$PATH:`pwd`

for i in $*
do
   shell040706PrimoA_recursive.sh $*
done