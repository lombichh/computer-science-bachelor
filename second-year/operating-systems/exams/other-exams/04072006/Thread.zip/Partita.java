//
//  Partita.java
//  
//
//  Created by Eugenio Magistretti on 29/06/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

public class Partita {

public static void main(String[] args) {
	Rigori rig=new Rigori();
	Arbitro arb=new Arbitro(rig);
	Giocatore g1=new Giocatore(0,1,1,rig);
	Giocatore g2=new Giocatore(1,1,1,rig);
	Giocatore g3=new Giocatore(0,2,0,rig);
	Giocatore g4=new Giocatore(1,2,1,rig);
	Giocatore g5=new Giocatore(0,3,0,rig);
	Giocatore g6=new Giocatore(1,3,0,rig);
	Giocatore g7=new Giocatore(0,4,0,rig);
	Giocatore g8=new Giocatore(1,4,1,rig);
	Giocatore g9=new Giocatore(0,5,1,rig);
	Giocatore g10=new Giocatore(1,5,0,rig);
	g1.start();
	g4.start();
	g7.start();
	g6.start();
	g9.start();
	g2.start();
	g3.start();
	g10.start();
	g5.start();
	g8.start();
	arb.start();
	}

}
