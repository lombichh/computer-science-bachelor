
public class Arbitro extends Thread{
	
	Rigori rig;
	
	public Arbitro( Rigori rig) {
		this.rig=rig;
		}
		
	public void run() {
		int finita=0;
		while(finita==0)
			finita=rig.check();
		}
	
}
