

public class Giocatore extends Thread{
	
	int squadra;
	int ordine;
	int segnato;
	Rigori rig;
	
	public Giocatore(int squadra, int ordine, int segnato, Rigori rig) {
		this.squadra=squadra;
		this.ordine=ordine;
		this.rig=rig;
		this.segnato=segnato;
		}
		
	public void run() {
		rig.rigore(squadra,ordine,segnato);		
		}
		
	
}
