

public class Rigori {

private int[] score;
private int[] tirati;
private int prossima;  //squadra a tirare i rigori
private int check;
private int partita_finita;


public Rigori(){
	score=new int[2];
	tirati=new int[2];
	score[0]=score[1]=tirati[0]=tirati[1]=partita_finita=0;
	prossima=1;
	check=1;
}

public synchronized void rigore(int squadra, int ordine, int segnato){
	while(prossima!=squadra || ordine!=tirati[squadra]+1 || check!=0 || partita_finita==1) {
			if(partita_finita==1)return;
			try{wait();}catch(InterruptedException e){}
			}
	tirati[squadra]++;
	prossima=1-squadra;
	score[squadra]+=segnato;
	check=1;
	notifyAll();
	if(segnato==1) System.out.println("La squadra "+squadra+" ha tirato il rigore numero "+ordine+" e ha segnato ");
	else System.out.println("La squadra "+squadra+" ha tirato il rigore numero "+ordine+" e non ha segnato ");
	}
	
public synchronized int check() {
	int diff,svant;
	while(check==0) try{wait();}catch(InterruptedException e){}
	svant=score[0]>score[1]?1:0;
	check=0;
	if(tirati[0]==tirati[1] && score[0]!=score[1])  {
		System.out.println("La squadra "+svant+" ha perso");
		partita_finita=1;
		notifyAll();
		return 1;
		}
	if(tirati[0]==5 && tirati[1]==5)	{
		System.out.println("La partita e' finita in parita'");
		return 1;
		}
	else {
		notifyAll();
		return 0;
		}
	}
		 

}
