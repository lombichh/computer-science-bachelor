public class visitatore extends Thread{
	private final int EST=0;
	private final int OVEST=1;
	
	monitor g;
	int provenienza;
	
	public visitatore(monitor G, int D){
		g=G;
		provenienza=D;
	
	}
	
	public void run() {
		try {
				if (provenienza==EST)
				{	g.EntraTrattoE(provenienza);
					sleep((int)(Math.random()*1000));
					g.EsciTrattoE(provenienza);
					sleep((int)(Math.random()*5000));// permanenza nella terrazza
					g.EntraTrattoO(provenienza);
					sleep((int)(Math.random()*1000));
					g.EsciTrattoO(provenienza);
				}
				else
				{	g.EntraTrattoO(provenienza);
					sleep((int)(Math.random()*1000));
					g.EsciTrattoO(provenienza);
					sleep((int)(Math.random()*5000));// permanenza nella terrazza
					g.EntraTrattoE(provenienza);
					sleep((int)(Math.random()*1000));
					g.EsciTrattoE(provenienza);
				}
				
		} catch (Exception e) {}
		 
		
	}
}