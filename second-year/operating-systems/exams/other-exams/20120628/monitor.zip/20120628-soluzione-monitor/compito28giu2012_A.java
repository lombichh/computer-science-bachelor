//
//  compito28giu2012_A.java
//  compito28giu2012.A
//
//  Created by anna ciampolini on 04/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//
import java.util.*;
import java.util.Random;

public class compito28giu2012_A {

        public static void main(String[] args) {
		int N=50;
		Random rand = new Random();
		int i, dir;
		
		int NV;
		visitatore [] V = new visitatore[N];
		
		monitor g=new monitor();
		
		for (i=0;i<N;i++) //creazione uomini e donne
		{	dir=rand.nextInt(2);
			V[i] = new visitatore(g,dir);
		}
		for (i=0;i<N;i++) //attivazione
			V[i].start();
		
				

	}   
}


