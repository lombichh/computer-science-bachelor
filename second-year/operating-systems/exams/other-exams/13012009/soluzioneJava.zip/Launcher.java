public class Launcher {

	public static void main(String[] args){
		Chef chef = new Chef();
		AddettoForno af1 = new AddettoForno(chef);
		AddettoForno af2 = new AddettoForno(chef);
		Timer t = new Timer (chef);
		AiutoCuoco t1= new AiutoCuoco(chef, 0, 4);
		AiutoCuoco t2= new AiutoCuoco(chef, 0, 4);
		AiutoCuoco t3= new AiutoCuoco(chef, 0, 4);
		AiutoCuoco t4= new AiutoCuoco(chef, 1, 10);
		AiutoCuoco t5= new AiutoCuoco(chef, 2, 5);
		AiutoCuoco t6= new AiutoCuoco(chef, 2, 5);
		AiutoCuoco t7= new AiutoCuoco(chef, 2, 5);

		AiutoCuoco t8= new AiutoCuoco(chef, 3, 10);
		AiutoCuoco t9= new AiutoCuoco(chef, 0, 5);
		AiutoCuoco t10= new AiutoCuoco(chef, 0, 7);
		AiutoCuoco t11= new AiutoCuoco(chef, 1, 10);
		AiutoCuoco t12= new AiutoCuoco(chef, 2, 10);
		
		t.start();
		af1.start();
		af2.start();
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
		t6.start();
		t7.start();

		try{Thread.sleep(10000);}catch(InterruptedException e){}


		t8.start();
		t9.start();
		t10.start();
		t11.start();
		t12.start();

	}

}
