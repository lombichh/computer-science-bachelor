import java.util.Date;
public class Chef{

	public static final int N = 10;
	int conteggioFornitori = 0;//[] = new int[]{0,0,0,0};//l'indice rappresenta il tipo di ingrediente cui si sta facendo riferimento

	int quantitaIngredienti[] = new int[]{0,0,0,0}; //l'indice rappresenta il tipo di ingrediente cui si sta facendo riferimento



	public synchronized void portaIngrediente(String id,int tipo,int quantita){
		long istante_richiesta = new Date().getTime();
		conteggioFornitori++;
		int posizione_coda=conteggioFornitori;
		long ingresso_in_coda = new java.util.Date().getTime();
		//System.out.println("Nuovo aiutocuoco in coda in posizione: "+posizione_coda );

		while (quantitaIngredienti[tipo] >= N && (new java.util.Date().getTime() - ingresso_in_coda < AiutoCuoco.MAX_QUEUED_TIME || posizione_coda != conteggioFornitori) ){
			try{wait();}
			catch(InterruptedException e){e.printStackTrace();}
		}

		if(! (new java.util.Date().getTime() - ingresso_in_coda < AiutoCuoco.MAX_QUEUED_TIME || posizione_coda != conteggioFornitori) ){
	
			System.out.println("Forzatura");

			for (int i= 0; i<quantitaIngredienti.length; i++){
				if (quantitaIngredienti[i] < N){
					int quantitaNecessaria = N - quantitaIngredienti[i] ;
					quantitaIngredienti[i] += quantitaNecessaria;
					System.out.print("Forzato Nuovo ingrediente di tipo: " + i +" da aiuto cuoco "+id);
					System.out.println(" {"+quantitaIngredienti[0]+","+quantitaIngredienti[1]+","+quantitaIngredienti[2]+","+quantitaIngredienti[3]+"}");

				}
			}
		}
		else{
			quantitaIngredienti[tipo] += quantita;
			System.out.print("Nuovo ingrediente di tipo: " + tipo+" da aiuto cuoco "+id +";");
			System.out.println("{"+quantitaIngredienti[0]+","+quantitaIngredienti[1]+","+quantitaIngredienti[2]+","+quantitaIngredienti[3]+"}");
		}
		notifyAll();
	}

	public synchronized void cuoci(){
		while ( ! (quantitaIngredienti[0] >= N && quantitaIngredienti[1] >= N && quantitaIngredienti[2] == N   && quantitaIngredienti[3] >= N  )  ) {
			try{wait();}
			catch(InterruptedException e){e.printStackTrace();}
		}
		System.out.println("Cottura!");		
		quantitaIngredienti=new int[]{0,0,0,0};
		notifyAll();
	}

	public synchronized void sblocca(){
		//System.out.println("Sblocco; coda di "+conteggioFornitori +" aiuto cuochi");	
		notifyAll();
	}

}
