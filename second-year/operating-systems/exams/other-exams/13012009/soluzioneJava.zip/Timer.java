public class Timer extends Thread {
	public Chef chef;

	public Timer(Chef chef){
		this.chef=chef;
	}
	
	public void run(){
		for (int i=0; i<20;i++){
			try{Thread.sleep(1000);}catch(InterruptedException e){}
			chef.sblocca();
		}
	}
}
