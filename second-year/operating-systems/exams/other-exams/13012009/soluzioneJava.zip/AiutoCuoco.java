public class AiutoCuoco extends Thread {
	public static final int	MAX_QUEUED_TIME = 2000;
	public Chef chef;
	int tipoIngrediente;
	int quantita;

	public AiutoCuoco(Chef chef,int tipoIngrediente, int quantita){
		this.chef=chef;
		this.tipoIngrediente=tipoIngrediente;
		this.quantita=quantita;
	}
	
	public void run(){
		chef.portaIngrediente(this.getName(),tipoIngrediente,quantita);
	}
}
