public class AddettoForno extends Thread {
	public Chef chef;

	public AddettoForno(Chef chef){
		this.chef=chef;
	}
	
	public void run(){
		chef.cuoci();
	}
}
