#!/bin/sh

temp=~/temp.txt
cd "$3"
count=0

for f in *
do
	if test -d "$f"
	then 
		$0 "$1" "$2" "$f"
	elif test -f "$f"
	then
		#test del gruppo
		group=`ls -lh "$f" | cut -d ' ' -f 2` 
	
		if test $group = "$1"
		then 
			#test delle occorrenze
			count=cat "$f" | grep -o "$2" | wc -l
			echo "$count volte la stringa "$f"" >> $temp #scrivo in append
		fi
	fi

done



	
	


