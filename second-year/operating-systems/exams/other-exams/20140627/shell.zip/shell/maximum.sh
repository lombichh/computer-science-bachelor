#!/bin/sh

# controllo numero di parametri
if ! test $# -eq 3
then echo "Numero di parametri errato"
exit 1
fi

# controllo che <dir> sia un direttorio assoluto
case $3 in
/*) ;;
*) echo "$3 non è un direttorio assoluto"
exit 2;;
esac

if ! test -d "$3"
then echo "$3 non è un direttorio valido"
exit 3
fi


temp=~/temp.txt # ~ equivale al percorso assoluto della mia home directory, analogamente alla variabile globale $HOME
> $temp # creo il file temp.txt nella mia home directory 


oldpath=$PATH
PATH=$PATH:`pwd`

maximum_rec.sh "$1" "$2" "$3"
echo grep "$2" | sort -n | head -n 1 < $temp

PATH=$oldpath





