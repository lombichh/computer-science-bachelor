import java.util.Random;


public class Gruppo extends Thread {
	
	Monitor m;
	int numPersone;
	String id;
	

	public Gruppo(Monitor m, String id) {
		this.m=m;
		Random r = new Random();
		numPersone=r.nextInt(8) + 1;
		this.id= id +" di "+ numPersone + " persone";
	}
	
	@Override
	public void run() {
		try {
			m.noleggioPattino(id, numPersone);
			Thread.sleep(5000); 
			m.restituisciPattino(id, numPersone);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	

}
