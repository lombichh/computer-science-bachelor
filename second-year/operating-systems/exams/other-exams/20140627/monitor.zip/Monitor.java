import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class Monitor {
	
	private int N;
	private int cassa;
	private Lock lock;
	private Condition[] codaGruppiInEntrata;
	private int[] numGruppiInCodaEntrata;
	private Condition[] codaGruppiInUscita;
	private int[] numGruppiInCodaUscita;
	private boolean presenzaAddetto;
	
	public Monitor(int N) {
		
		this.N=N;
		cassa=0;
	
		lock=new ReentrantLock();
		
		// una coda per ogni tipo di gruppo in entrata
		codaGruppiInEntrata= new Condition[8];
		for(int i =0; i<codaGruppiInEntrata.length;i++) {
			codaGruppiInEntrata[i]=lock.newCondition();
		}
		numGruppiInCodaEntrata = new int[8];
		for(int i =0; i<numGruppiInCodaEntrata.length;i++) {
			numGruppiInCodaEntrata[i]=0;
		}
		
		// una coda per ogni tipo di gruppo in uscita
		codaGruppiInUscita= new Condition[8];
		for(int i =0; i<codaGruppiInUscita.length;i++) {
			codaGruppiInUscita[i]=lock.newCondition();
		}
		numGruppiInCodaUscita = new int[8];
		for(int i =0; i<numGruppiInCodaUscita.length;i++) {
			numGruppiInCodaUscita[i]=0;
		}
		
		presenzaAddetto=true;
	}
	
	private String datiToString() {
		return " cassa = " + cassa + " e numero pattini = " + N;
	}
	
	public void noleggioPattino(String id, int numPersone) throws InterruptedException {
		lock.lock();
		try{
			while(!condizioneNoleggio(numPersone)) {
				numGruppiInCodaEntrata[numPersone-1]++;
				codaGruppiInEntrata[numPersone-1].await();
				numGruppiInCodaEntrata[numPersone-1]--;
			}

			pagaEPrendi(numPersone);
			//annuncio di avere noleggiato il pattino
			int pattini = numPersone > 4 ? 2 : 1;
			System.out.println(id +" ha noleggiato "+pattini+" pattino/i" + datiToString());
			//svegliare eventuali processi che aspettavano soldi
			//sveglio le code partendo dal gruppo + numeroso
			for(int i = 7; i>=0; i--){
				codaGruppiInUscita[i].signalAll();				
			}
		} finally {
			lock.unlock();
		}
	}
	
	//check condizioni di noleggio
	private boolean condizioneNoleggio(int numPersone) {
		//controllo se ci sono pattini disponibili
		boolean pattiniDisponibili;
		if(numPersone>4) {
			pattiniDisponibili = N > 1 ? true : false;	
		}
		else {
			pattiniDisponibili = N>0? true : false;
		}
		//controllo se sono presenti gruppi meno numerosi in coda
		boolean presenzaGruppiMenoNumerosi=false;
		if(numPersone==1){
			if (numGruppiInCodaEntrata[0]>0) presenzaGruppiMenoNumerosi=false;
		} else {
			for(int i=0;i<numPersone-1;i++){
				if(numGruppiInCodaEntrata[i]>0) presenzaGruppiMenoNumerosi=true;
			}
		}
		
		return pattiniDisponibili && presenzaAddetto && !presenzaGruppiMenoNumerosi;
		
	}

	//operazioni di pagamento e prelievo
	private void pagaEPrendi(int numPersone) {
		if (numPersone>4) { //se servono due pattini
			cassa= cassa+14;
			N=N-2;
		} else { //se serve un pattino solo
			cassa=cassa+7;
			N--;
		}
	}
	
	//restituzione pattino
	public void restituisciPattino(String id, int numPersone) throws InterruptedException {
		lock.lock();
		try {
			while(!condizioneRestituzione(numPersone)) {
				numGruppiInCodaUscita[numPersone-1]++;
				codaGruppiInUscita[numPersone-1].await();
				numGruppiInCodaUscita[numPersone-1]--;
			}
			//restituisci e prendi la cauzione
			restituisciEPrendiCauzione(numPersone);
			int pattini = numPersone > 4 ? 2 : 1;
			System.out.println(id +" ha restituito "+pattini+" pattino/i" + datiToString());
			//svegliare eventuali processi che aspettavano pattini
			//sveglio le code partendo dal gruppo meno numeroso
			for(int i = 0; i<codaGruppiInEntrata.length; i++){
				codaGruppiInEntrata[i].signalAll();				
			}
		} finally {
			lock.unlock();
		}
	}

	//check restituzione
	private boolean condizioneRestituzione(int numPersone) {
		//controllo se ci sono soldi disponibili
		boolean soldiDisponibili;
		if(numPersone>4) {
			soldiDisponibili = cassa > 5 ? true : false;	
		}
		else {
			soldiDisponibili = cassa>2? true : false;
		}
		//controllo se sono presenti gruppi + numerosi in coda
		boolean presenzaGruppiPiuNumerosi=false;
		if(numPersone==8) {
			if(numGruppiInCodaUscita[7]>0) presenzaGruppiPiuNumerosi=false;
		}
		else {
			for(int i=7;i>numPersone-1;i--){
				if(numGruppiInCodaUscita[i]>0) presenzaGruppiPiuNumerosi=true;
			}
		}
		return soldiDisponibili && presenzaAddetto && !presenzaGruppiPiuNumerosi;
	}

	//operazioni di restituzione
	private void restituisciEPrendiCauzione(int numPersone) {
		if (numPersone>4) { //se restituiscono due pattini
			cassa= cassa -6;
			N=N+2;
		} else { //se serve un pattino solo
			cassa=cassa-3;
			N++;
		}
	}
	
	public void addettoClose() {
		lock.lock();
		try {
			presenzaAddetto=false;
			if (cassa>3) cassa=3;
			System.out.println("L'addetto chiude il noleggio");
		} finally {
			lock.unlock();
		}
	}
	
	public void addettoOpen() {
		lock.lock();
		try {
			presenzaAddetto=true;
			System.out.println("L'addetto apre il noleggio");
			for(int i = 0; i<codaGruppiInEntrata.length; i++){
				codaGruppiInEntrata[i].signalAll();				
			}
			for(int i = 7; i>=0; i--){
				codaGruppiInUscita[i].signalAll();				
			}
		} finally {
			lock.unlock();
		}
	}

}
