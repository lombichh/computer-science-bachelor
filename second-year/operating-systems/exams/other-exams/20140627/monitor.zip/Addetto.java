import java.util.Random;


public class Addetto extends Thread {
	
	Random random;
	Monitor m;
	
	public Addetto(Monitor m) {
		random=new Random();
		this.m=m;
	}
	
	@Override
	public void run() {
		
		try {
			while(true) {
				Thread.sleep(1000*random.nextInt(20));
				m.addettoClose();
				Thread.sleep(1000*random.nextInt(20));
				m.addettoOpen();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
