
public class Noleggio {

	public static void main(String[] args) {
		
		final int numGruppi=100;
		final int numPattini=10;
		
		Monitor m = new Monitor(numPattini);
		Addetto addetto = new Addetto(m);
		Gruppo[] gruppi = new Gruppo[numGruppi];
		for(int i=0;i<gruppi.length;i++) {
			String id = "Gruppo " + i;
			gruppi[i]=new Gruppo(m, id);
		}
		addetto.start();
		for(int i=0;i<gruppi.length;i++) {
			gruppi[i].start();
		}

	}

}
