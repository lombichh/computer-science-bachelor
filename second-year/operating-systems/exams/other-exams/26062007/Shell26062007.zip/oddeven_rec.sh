#!/bin/sh

cd "$1"
x=0
trovato=0

for i in  *
do
   if test -h "$i" 
   then
	continue
   fi
   if test -f "$i"
   then
	case "$i" in 
		?????) trovato=1;;
		*);;
	esac
	continue
   fi		
   if test -d "$i"
   then
	$0 "$i" "$2" "$3"
	x=`expr $x + 1`
   fi  	 	
done

if test $x -ne 0 -a $trovato -eq 1
then
   s=`expr $x %  2`
   if test $s -eq 1 
   then
      echo  `pwd` $x >>$2
   else
      echo  `pwd` $x >>$3
   fi
fi
