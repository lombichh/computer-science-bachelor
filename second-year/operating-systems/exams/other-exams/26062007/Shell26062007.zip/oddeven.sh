#!/bin/sh

if test $# -ne 3
then
    echo "usage: oddeven <dir> <fodd> <feven>"
    exit 1
fi	
if ! test -d "$1"
then
   echo "First argument should be a dir"
   exit 1	
fi
case "$1" in
   /*);;
    *) echo "First argument should be an absolute dir"
       exit 1 ;;	
esac	

if test -f "$2" 
then
   echo "File $2 is already there"
   exit 1
fi
if test -f "$3" 
then
   echo "File $3 is already there"
   exit 1
fi

oldpath=$PATH
PATH=$PATH:`pwd`
oddeven_rec.sh "$1" "$2" "$3"
PATH=$oldpath

if ! test -f "$2"
then
  echo "File dispari non creato"  
else
  rev $2 | sort -r | rev >$2
fi
if ! test -f "$3"
then
  echo "File pari non creato"
else
  rev $3 | sort -r | rev >$3
fi
