
public class Documento extends Thread {

	public static int TXT_PRINT_TIME = 7;
	public static int IMG_PRINT_TIME = 15;

	int MAX_PRINT_DELAY = 10000;
	Stampante queue;
	boolean txt;
	int id;
	int document_dim;

	public Documento(Stampante queue, boolean txt, int id){
		this.queue=queue;
		this.txt=txt;
		this.id=id;
	}
	
	public void run(){
		if(txt)req_txt();
		else req_img();
	 
		}
		
	public void req_txt(){
	   	int expected_print_time = queue.acquire_txt(id);
		try{Thread.sleep(MAX_PRINT_DELAY);}catch(InterruptedException e){}
		queue.report(id,txt,expected_print_time);
		}
		
	public void req_img(){
		int expected_print_time = queue.acquire_img(id);
		try{Thread.sleep(MAX_PRINT_DELAY);}catch(InterruptedException e){}
		queue.report(id,txt,expected_print_time);
		}
}
