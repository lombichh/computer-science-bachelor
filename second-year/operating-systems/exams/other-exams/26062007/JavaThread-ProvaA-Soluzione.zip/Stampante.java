public class Stampante{

private int current_txt_queue=0; 
private int current_img_queue=0; 
private int current_txt_served=0;
private int current_img_served=0;
private int in_service=0;
private int out_service=0;
private int DIM_BUFFER=3;
private int global_expected_print_time=0;


public synchronized int acquire_img(int id){

	int my_pos=current_img_queue;
	current_img_queue++;

	//salvo il tempo di stimato attesa corrente in una variabile locale al metodo
	int local_print_time = global_expected_print_time;

	System.out.println("Documento img "+id+" entrato");	
	try{
		while(my_pos>current_img_served || current_txt_queue>current_txt_served || in_service==DIM_BUFFER ){
			wait();
			}
		} catch(InterruptedException e){}

	//aggiorno il tempo totale atteso di stampa
	global_expected_print_time+=Documento.IMG_PRINT_TIME;

	current_img_served++;
	in_service++;
	notifyAll();
	System.out.println("Documento img "+id+" in servizio");
	System.out.println("Dimensione corrente Buffer "+in_service);
	return local_print_time;
	}

public synchronized int acquire_txt(int id){
	int my_pos=current_txt_queue;
	current_txt_queue++;
	System.out.println("Documento txt "+id+" entrato");
	//salvo il tempo di stimato attesa corrente in una variabile locale al metodo
	int local_print_time = global_expected_print_time;

	try{
		while(my_pos>current_txt_served || in_service==DIM_BUFFER){
			wait();
			}
		} catch(InterruptedException e){}
	//aggiorno il tempo totale atteso di stampa
	global_expected_print_time+=Documento.TXT_PRINT_TIME;


	current_txt_served++;			
	in_service ++;
	notifyAll();
	System.out.println("Documento txt "+id+" in servizio");
	System.out.println("Dimensione corrente Buffer "+in_service);
	return local_print_time;
	
	}

	
public synchronized void report(int id,	boolean txt, int expected_print_time){

	out_service++;
	System.out.println("================");
	System.out.println("Printed document: "+id);
	System.out.println("Expected print time: "+expected_print_time);

	if(out_service==DIM_BUFFER) {
		System.out.println("Nuovo batch di stampa");
		in_service=out_service=0;
		notifyAll();
		}
	}
	
}
