
public class Launcher {

public static void main(String[] args){
	Stampante queue=new Stampante();
	Documento r1=new Documento(queue,true,1);
	Documento r2=new Documento(queue,false,2);
	Documento r3=new Documento(queue,false,3);
	Documento r4=new Documento(queue,true,4);
	Documento r5=new Documento(queue,false,5);
	Documento r6=new Documento(queue,false,6);
	Documento r7=new Documento(queue,true,7);
	Documento r8=new Documento(queue,false,8);
	Documento r9=new Documento(queue,true,9);
	
	r1.start();
	r2.start();
	r3.start();
	try{Thread.sleep(3000);}catch(InterruptedException e){}
	r4.start();
	r5.start();
	r6.start();
	r7.start();
	r8.start();
	r9.start();
	}

}
