#!/bin/sh
cd "$1"
count=0
for f in *
do

	if test -d "$f"
	then
		$0 "$f" "$2" "$3"

	elif test -f "$f"
	then
		exec_right=`ls -lh "$f" | cut -c 4`
		if test $exec_right = x
		then
			count=`expr $count + 1`
		fi
	fi

done
if test $count -gt $3
then
	echo trovati $count eseguibili in $1 >> $2/report.txt
fi
