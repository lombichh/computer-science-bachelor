#!/bin/sh

if ! test $# -eq 3
then    
   echo "usage:$0 <dirIn> <owner> <N>"    
   exit 1
fi

case $1 in    
	/*) ;;    
	*)  echo "$1 is not an absolute directory"        	
	    exit 4;;
esac
if ! test -d "$1"
then    
	echo "$1 is not a valid directory"    
	exit 5
fi



oldpath=$PATH
PATH=$PATH:`pwd`
countLinks_rec.sh "$1" "$2" "$3"
PATH=$oldpath
