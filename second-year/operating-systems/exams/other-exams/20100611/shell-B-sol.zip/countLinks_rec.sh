#!/bin/sh
cd "$1"
count=0
for f in *
do

	if test -d "$f"
	then
		$0 "$f" "$2" "$3"

	elif test -h "$f"
	then
		owner=`ls -lh "$f" | cut -d ' ' -f 3`
		if test $owner = $2
		then
			count=`expr $count + 1`
		fi
	fi

done
if test $count -gt $3
then
	echo trovati $count link in $1 
fi
