//
//  cliente.java
//  banca
//
//  Created by anna ciampolini on 22/06/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

import  java.util.Random;


public class cliente extends Thread{
	private monitor M;
	private int conto, max;
	Random r =	new Random();
	
	public cliente(int conto, monitor m, int Nconti){
		this.M=m;
		this.conto=conto;
		this.max=Nconti;
	}

	public void run(){
	int op, cc, somma;
	try {
		System.out.print("Thread creato!\n");
		while (true)
		{	op=r.nextInt(2);
			//System.out.print("Operazione: "+op+" \n");
			if (op==0) //versamento
			{	
				cc= r.nextInt(max);
				somma= r.nextInt(10)*10000;
				//System.out.print("Thread inizia a versare euro"+ somma +" sul cc "+ cc+"...\n");
				M.versamento(cc, conto, somma);
				Thread.sleep(250);
				M.fine_operazione();
			}
		    else
			{	//System.out.print("Thread inizia a prelevare....\n");
				somma= r.nextInt(10)*10000;
				//System.out.print("Thread inizia a prelevare euro"+ somma +" dal suo cc ("+ conto+")...\n");
				M.prelievo(conto,somma);
				Thread.sleep(250);
				M.fine_operazione();
			}
			
					Thread.sleep(250);
		}
		} catch (InterruptedException e) {	}


	}
}
