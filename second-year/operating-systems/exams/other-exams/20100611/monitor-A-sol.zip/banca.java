//
//  banca.java
//  banca
//
//  Created by anna ciampolini on 21/06/10.
//  Copyright (c) 2010 __MyCompanyName__. All rights reserved.
//
import java.util.*;

public class banca {

    public static void main (String args[]) {
	final int NC=5;
	int i;
	cliente []Clienti= new cliente[NC];
	monitor M = new monitor();
		for (i = 0; i < NC; i++) {
			Clienti[i] = new cliente(i, M, NC);
			Clienti[i].start();
		}

    }
}
