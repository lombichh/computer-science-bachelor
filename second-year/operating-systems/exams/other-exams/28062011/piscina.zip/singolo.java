//
//  singolo.java
//  piscina
//
//  Created by anna ciampolini on 01/07/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

public class singolo extends Thread {
	Monitor m;
	int genere;
	
	
	public singolo (Monitor M,int GENERE) 
		{
		this.m=M;
		this.genere=GENERE;
		}
	
	public void run ()
	{   try {
			m.entraS(genere);
			sleep(4);
			m.esciS(genere);
		
		}catch(InterruptedException e){}
	}
	
}


