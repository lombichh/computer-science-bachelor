//
//  piscina.java
//  piscina
//
//  Created by anna ciampolini on 01/07/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//
import java.util.*;

public class piscina {
		 static final  int UOMO = 0;
		 static final  int DONNA = 1;
		 static final int N=5;
		 static final int MAX=8;
		 static final int nthreads=15;
		 
 	public static void main (String [] args)
	{
		
		
		Random rand = new Random();
		
		Monitor M = new Monitor(MAX,N);
		
		singolo []S = new singolo [nthreads];
		gruppo  []G = new gruppo [nthreads];
		
				
		for (int i=0;i<nthreads;i++)
			{
			 S[i] = new singolo(M,rand.nextInt(2));
			 G[i] = new gruppo(M,rand.nextInt(MAX-1)+2);
			}
		System.out.println("-----------------------------------------------------------------------");
		System.out.println("---- La piscina è aperta! ci sono "+ N +" cabine e "+ MAX + " posti----");
		System.out.println("-----------------------------------------------------------------------");

		for (int i=0;i<nthreads;i++)
			{
			S[i].start();
			G[i].start();
			}
		
	
	}
}