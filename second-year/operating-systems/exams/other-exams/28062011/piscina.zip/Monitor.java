//
//  Monitor.java
//  piscina
//
//  Created by anna ciampolini on 01/07/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

import java.util.concurrent.locks.*;


public class Monitor {
	private static final int U=0;
	private static final int D=1;
	private Lock lock = new ReentrantLock();
	private Condition codaG = lock.newCondition();
	private Condition [] codaS = new Condition[2]; // 0 uomo, 1 donna
	private int sospG;
	private int [] sospS= new int[2];
	private int IN, cabine_occ, gruppi;
	private int []singoli=new int[2]; // singoli nello spogliatoio per genere
	private int numCabine,NumeroPersoneIN;
	private int MAX, N;

	
	
	public Monitor(int max, int n) 
	{	this.MAX=max;		
		this.N=n;
		codaS[U] = lock.newCondition();	
		codaS[D] = lock.newCondition();	
		sospG=0;
		sospS[U]=0;
		sospS[D]=0;
		IN=0;
		cabine_occ=0;
		gruppi=0;
		singoli[U]=0;
		singoli[D]=0;		
	}
	
	

	public void entraS(int genere) throws InterruptedException 
	{	lock.lock();
		try {
			while(	gruppi>0 ||
					singoli[altro(genere)]>0 ||
					(genere==U && sospS[D]>0) ||
					sospG>0 ||
					IN==MAX ||
					cabine_occ==N )
			{		sospS[genere]++;
					codaS[genere].await();
					sospS[genere]--;
			}
			singoli[genere]++;
			cabine_occ++;
			IN++;
		 System.out.println("ENTRA SINGOLO di genere "+genere+"- ci sono "+IN+" persone nello spogliatoio;  cabine occupate= "+ cabine_occ);
		} finally {	lock.unlock(); }
	}
	
	
	public void entraG(int num) throws InterruptedException  
	{	lock.lock();
		try {//
			while(	singoli[D]+ singoli[U] > 0 ||
					IN+num> MAX ||
					cabine_occ==N )
			{		sospG++;
					codaG.await();
					sospG--;
			}
			gruppi++;
			cabine_occ++;
			IN+=num;
		 System.out.println("ENTRA GRUPPO di "+num+" PERSONE - ci sono "+IN+" persone nello spogliatoio;  cabine occupate= "+ cabine_occ);
		} finally {	lock.unlock();}
	}

	public void esciS(int genere) throws InterruptedException { 
		lock.lock();
		try {	singoli[genere]--;
				cabine_occ--;
				IN--;
				if (IN==0) // spogliatoio vuoto
				{	if (sospG>0)
						codaG.signalAll();
					else if ((genere==U)&&(sospS[D]>0))
						codaS[D].signalAll();
					else if ((genere==D)&&(sospS[U]>0)&& (sospS[D]==0))
						codaS[U].signalAll();
				}
				else	if ((genere==D)&& (sospS[D]>0))
							codaS[D].signal();
						else if ((genere==U)&&(sospS[U]>0))
							codaS[U].signal();
							
			 System.out.println("è uscito il singolo di genere "+genere +". Persone dentro= "+ IN +"; cabine occupate= "+ cabine_occ);
		} finally {	lock.unlock();}
	}
	
public void esciG(int num) throws InterruptedException { 
		lock.lock();
		try {	gruppi--;
				cabine_occ--;
				IN-=num;
				if (sospG>0)
						codaG.signalAll();
				else if (IN==0) // spogliatoio vuoto
				{	if (sospS[D]>0)
						codaS[D].signalAll();
					else if (sospS[U]>0)
						codaS[U].signalAll();
				}			
			 System.out.println("è uscito un gruppo di  "+num +" persone. persone dentro= "+ IN+"; cabine occupate= "+ cabine_occ);
		} finally {	lock.unlock();}
	}


private int altro(int genere)
{ if (genere==U)
		return D;
  else  return U;
}
	
}


