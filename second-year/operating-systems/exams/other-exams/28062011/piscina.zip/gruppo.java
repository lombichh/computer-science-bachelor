//
//  gruppo.java
//  piscina
//
//  Created by anna ciampolini on 01/07/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


public class gruppo extends Thread {
	Monitor m;
	int num;
	
	
	public gruppo (Monitor M,int NUM) 
		{
		this.m=M;
		this.num=NUM;
		}
	
	public void run ()
	{   try {
			m.entraG(num);
			sleep(4);
			m.esciG(num);
		
		}catch(InterruptedException e){}
	}
	
}





