
import  java.util.Random;


public class calzolaio extends Thread{
	private monitor M;
	
	Random r =	new Random();
	
	public calzolaio(monitor m){
		this.M=m;
	}

	public void run(){
	int misura, piede, tempo;
	try {
		System.out.print("Thread creato!\n");
		while (true)
		{	misura=r.nextInt(2); //definizione misura prossima scarpa
			piede=r.nextInt(2);  //definizione piede prossima scarpa
			System.out.print("Calzolaio: sto per creare una scarpa di misura "+misura+" per il piede "+piede+" \n");
			M.deposito(misura, piede);
			tempo=r.nextInt(300);
			Thread.sleep(tempo);
		}
	} catch (InterruptedException e) {	}


	}
}
