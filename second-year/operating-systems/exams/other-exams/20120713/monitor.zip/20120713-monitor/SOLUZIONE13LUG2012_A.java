//
//  SOLUZIONE13LUG2012_A.java
//  SOLUZIONE13LUG2012.A
//
//  Created by anna ciampolini on 16/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//
import java.util.*;

public class SOLUZIONE13LUG2012_A {
	private final int N=20;

    public static void main (String args[]) 
	{	int i;
		monitor M = new monitor();
		operaio O=new operaio(M);
		calzolaio []C= new calzolaio[20];
		O.start();
		for (i = 0; i < 20; i++) {
			C[i] = new calzolaio(M);
			C[i].start();
		}
	}
}
