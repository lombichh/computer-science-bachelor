
import  java.util.Random;


public class operaio extends Thread{
	private monitor M;
	private int conto, max;
	Random r =	new Random();
	
	public operaio(monitor m){
		this.M=m;
	}

	public void run(){
	int tempo;
	try {
		System.out.print("Thread creato!\n");
		while (true)
		{	tempo=r.nextInt(500);
			//System.out.print("Operazione: "+op+" \n");
			M.prelievo();
			Thread.sleep(tempo);
		}
	} catch (InterruptedException e) {	}


	}
}
