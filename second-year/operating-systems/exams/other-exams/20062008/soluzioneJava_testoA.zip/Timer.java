
public class Timer extends Thread {
	public static final int N = 20;
	HelpDesk queue;

	public Timer(HelpDesk queue){
		this.queue=queue;
	}
	
	public void run(){
		for (int i = 0; i< N;i++){
			try{Thread.sleep(500);}catch(InterruptedException e){}
			queue.check_time();
		}
	}
}
