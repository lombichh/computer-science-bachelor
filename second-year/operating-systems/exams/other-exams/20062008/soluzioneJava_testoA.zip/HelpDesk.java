public class HelpDesk{

private int current_business_queue=0; 
private int current_home_queue=0; 
private int current_business_served=0;
private int current_home_served=0;
public static final long N_MAX = 3000; 

public synchronized void check_time(){
	notifyAll();
}

public synchronized int acquire_home(){

	int my_pos=current_home_queue;
	current_home_queue++;

	long queue_time = new java.util.Date().getTime();
	int home_queued = current_home_queue - current_home_served -1;

	try{
		while(my_pos>current_home_served || 
			( new java.util.Date().getTime() - queue_time < N_MAX  && current_business_queue>current_business_served) ){
			wait();
		}
	} catch(InterruptedException e){}
	if (new java.util.Date().getTime() - queue_time >= N_MAX)
		System.out.println("Utente home "+Thread.currentThread().getName()+" entrato in coda per tempo massimo raggiunto");
	else
		System.out.println("Utente home "+Thread.currentThread().getName()+" entrato in coda");
	return home_queued;
}

public synchronized int acquire_business(){
	int my_pos=current_business_queue;
	current_business_queue++;

	int business_queued = current_business_queue - current_business_served -1;

	try{
		while(my_pos>current_business_served ){
			wait();
		}
	} catch(InterruptedException e){}
	
	System.out.println("Utente business "+Thread.currentThread().getName()+" entrato in coda");
	return business_queued;
	
}

	
public synchronized void report(boolean business, int queued){
	if(business)
		current_business_served++;
	else
		current_home_served++;


	if (business)
		System.out.println("-->Utente business "+Thread.currentThread().getName()+" uscito; utenti business presenti in coda all'ingresso: "+queued);
	else
		System.out.println("-->Utente home "+Thread.currentThread().getName()+" uscito; utenti home presenti in coda all'ingresso: "+queued);

	notifyAll();
}
	
}
