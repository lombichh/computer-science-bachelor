
public class Cliente extends Thread {
	public static final int DELAY = 2000;
	HelpDesk queue;
	boolean business; //flag per differenziare clienti business oppure home

	public Cliente(HelpDesk queue, boolean business){
		this.queue=queue;
		this.business=business;
	}
	
	public void run(){
		if(business)req_business();
		else req_home();
	 
		}
		
	public void req_business(){
	   	int queued = queue.acquire_business();
		try{Thread.sleep(DELAY);}catch(InterruptedException e){}
		queue.report(business, queued);
	}
		
	public void req_home(){
		int queued = queue.acquire_home();
		try{Thread.sleep(DELAY);}catch(InterruptedException e){}
		queue.report(business, queued);
	}
}
