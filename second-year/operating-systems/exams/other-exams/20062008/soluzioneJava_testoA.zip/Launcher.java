
public class Launcher {

public static void main(String[] args){
	HelpDesk queue=new HelpDesk();
	Timer t = new Timer(queue);
	Cliente c1=new Cliente(queue,true);
	Cliente c2=new Cliente(queue,false);
	Cliente c3=new Cliente(queue,false);
	Cliente c4=new Cliente(queue,false);
	Cliente c5=new Cliente(queue,true);
	Cliente c6=new Cliente(queue,false);
	Cliente c7=new Cliente(queue,true);
	Cliente c8=new Cliente(queue,false);
	Cliente c9=new Cliente(queue,true);
	t.start();	
	c1.start();
	c2.start();
	c3.start();
	c4.start();
	c5.start();
	try{Thread.sleep(10000);}catch(InterruptedException e){}
	c6.start();
	c7.start();
	c8.start();
	c9.start();
}

}
