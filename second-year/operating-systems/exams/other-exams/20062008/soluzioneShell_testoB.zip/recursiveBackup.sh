#!/bin/sh

cd "$1"
dateFolder=backup_`date +%F_%T`

if ! test -d "$2"; then
	mkdir "$2"
fi 

for f in *
do    
	if test -h "$f" #se il file corrente e' un link
	then        
	 	continue

	elif test -d "$f"
   	then        
	 	$0 $1/"$f" $2/"$f"
	elif test -f "$f"
	then
		
		if ! test -e $2/"$f"; then
			cp "$f" $2/"$f"
		elif test `stat --format=%Z $1/"$f"` -gt `stat --format=%Z $2/"$f"`; then
			echo "found modification for $1/"$f""
			if ! test -e $2/$dateFolder; then
				mkdir $2/$dateFolder
			fi
			cp $2/"$f" $2/$dateFolder/"$f"
			cp "$f" $2/"$f"
		fi 
	fi	
done

