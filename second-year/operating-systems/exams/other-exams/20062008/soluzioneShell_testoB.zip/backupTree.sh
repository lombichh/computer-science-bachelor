#!/bin/sh

if test $# -ne 2
then    
   echo "usage:$0 <scrDir> <destDir>"    
   exit 1
fi

for i in $* 
   do 
   case $i in    
	/*) ;;    
	*)  echo "$i is not an absolute directory"        	
  	    exit 4;;
   esac
   if ! test -d "$i"
   then    
	echo "$i is not a valid directory"
	exit 5
   fi
done

oldpath=$PATH
PATH=$PATH:`pwd`

   recursiveBackup.sh $1 $2
PATH=$oldpath

