#22 giugno 2009 - TURNO 1 COMPITO B
#! /bin/bash

cd "$1"

for f in *
do
	if test -h "$f"
	then
		continue

	elif test -d "$f"
	then
		echo "Ricorsione nella cartella $f"
		trova.sh "$f" "$2" "$3"

	elif test -f "$f"
	then
		grep "$3" "$f" >> "$2"
	fi
done
