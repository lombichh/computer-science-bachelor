#22 giugno 2009 - TURNO 1 COMPITO B
#! /bin/bash


if test $# -ne 3
then
	echo "Usage: $0 dir FileOut parola"
	exit -1
fi 

if ! test -d "$1"
then
	echo "$1 non e' una directory valida"
	exit -2
fi

case "$1" in
	/*) ;;
	 *) echo "dir deve avere nome assoluto"
	    exit -3 ;; 

esac

case "$2" in
	/*) ;;
	 *) echo "FileOut deve avere nome assoluto"
	    exit -4 ;;
esac

if test -z "$3"
then
	echo "Parola non e' valida"
	exit -5
fi

oldpath=$PATH
PATH=$PATH:`pwd`

trova.sh "$1" "$2" "$3"

trovate=`wc -l "$2" | cut -f1 -d" "`

echo "Il numero di righe di $2 e' $trovate"

PATH=$oldpath
