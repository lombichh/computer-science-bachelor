//
//  risorsa.java
//  radiologia
//
//  Created by anna ciampolini on 02/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//


import java.util.*;

public class risorsa
{
    private final int max=100;
	int buste, referti; 
	int da_inserire, da_prelevare;
	private String []cassetta;
	private List archivio;
    private Semaforo sM, sDeposito, sPrelievo;
    private String radiografia;

    
    
    
    public risorsa()
    {
        this.buste=0;
        this.referti=0;
		da_inserire=0;
		da_prelevare=0;
        cassetta=new String[max];
		archivio=new Vector();
        sM=new Semaforo(1);
        sPrelievo=new Semaforo(0);
        sDeposito=new Semaforo(max);
        
        
    }
    
    public void deposita(String radiografia)
    {
        sDeposito.p();
        sM.p();
		cassetta[da_inserire]=radiografia;
		buste++;
		da_inserire=(da_inserire+1)%max;
		System.out.println("tecnico : inserita radiografia - totale "+buste);
        
        sPrelievo.v();
        sM.v();
    }

    
    
    public String estrai()
    {		String radiografia;
        
	      	sPrelievo.p();
	      	sM.p();                        	
	        radiografia=cassetta[da_prelevare];
			buste--;
			da_prelevare=(da_prelevare+1)%max;
			System.out.println("medico: estrazione radiografia - ne rimangono "+buste);
            sM.v();
	        sDeposito.v();     
	        return radiografia;
	
    }

	public  void archivia(String referto)
	{
		sM.p();
		archivio.add(radiografia);
		referti++;
		System.out.println("medico: inserito referto - totale referti:  "+referti);
		sM.v();
	}

}

