//
//  semaforo.java
//  radiologia
//
//  Created by anna ciampolini on 02/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

public class Semaforo 
{
    private int value;


    public Semaforo(int valoreIniziale)
    {
        this.value=valoreIniziale;
    }


    public synchronized void p()
    {
        if (value==0)
            try
            {
                wait();
            }
            catch(InterruptedException e){}
    
            value--;
    }


    public synchronized void v()
    {
        value++;
        notify();
    }


}
