//
//  Tecnico.java
//  radiologia
//
//  Created by anna ciampolini on 02/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

public class Tecnico extends Thread
{

private risorsa r;
private String radiografia="";


    public Tecnico (risorsa R)
    {
        this.r=R;
              
    }
    
    public void run()
    {
        
       
       
        for(int i=0; i<5; i++)
        {
            
            radiografia="radiografia eseguita da"+getName();
            r.deposita(radiografia);
            
            try
            {
            	sleep((int)(Math.random()*10));
            }catch(InterruptedException e) {}
            
           
        }
    }

}