//
//  Medico.java
//  radiologia
//
//  Created by anna ciampolini on 02/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//


public class Medico extends Thread
{

private risorsa r;
private String radiografia;


    public Medico (risorsa R)
    {
        this.r=R;
	}
    
    public void run()
    {
       try{
        for(;;)
        {
            
            radiografia= r.estrai();
			
			System.out.println("medico ha estratto: "+ radiografia);
            sleep((int)(Math.random()*10));
            r.archivia(radiografia + "- eseguito  referto da"+ getName());
			System.out.println("medico: "+ radiografia+ "- eseguito  referto da"+ getName());

		}
            
            
       }catch(InterruptedException e) {}
                
        
    }

}
