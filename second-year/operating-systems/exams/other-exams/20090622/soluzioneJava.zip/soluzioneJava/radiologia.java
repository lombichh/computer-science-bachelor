//
//  radiologia.java
//  radiologia
//
//  Created by anna ciampolini on 02/07/09.
//  Copyright (c) 2009 __MyCompanyName__. All rights reserved.
//
//	For information on setting Java configuration information, including 
//	setting Java properties, refer to the documentation at
//		http://developer.apple.com/techpubs/java/java.html
//

import java.util.*;


public class radiologia
{


    public static void main(String[] args) 
    {
        
        final int MAX=10, N=10;
        
        risorsa R=new risorsa();
        Medico doct=new Medico(R);
        Tecnico[] tecn;
        tecn=new Tecnico[N];
        for(int i=0; i<N; i++)
                tecn[i]=new Tecnico(R);
        

	

                
        System.out.println("avvio i threads");
        
        doct.start();
        
        
        for(int i=0; i<N; i++)
        {
            tecn[i].start();
        }
        
    }   


}
