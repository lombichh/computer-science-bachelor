import java.util.Date;
public class Stazione{
	private final static long T_MAX = 2000;// soglia di obsolescenza: 2 secondi
	boolean campioniDisponibili[] = new boolean[]{false,false,false}; //l'indice rappresenta il tipo di campione cui si sta facendo riferimento
	int campioni[] = new int[]{0,0,0}; //l'indice rappresenta il tipo di campione cui si sta facendo riferimento

	public synchronized void generaBollettino (int durataElaborazione){
		while (!campioniDisponibili[0] || !campioniDisponibili[1] || !campioniDisponibili[2]){
			try{wait();}
			catch(InterruptedException e){e.printStackTrace();}
		}

		try{Thread.sleep(durataElaborazione);}catch(InterruptedException e){}

		System.out.println("******************************");
		System.out.println("Nuovo bollettino meteorologico : \nPressione : " + campioni[0] + "mm Hg\nTemperatura: " + campioni[1] + "°C\nUmidita: " + campioni[2] +"%\n");
		campioniDisponibili=new boolean[]{false,false,false};
		campioni=new int[]{0,0,0};
		notifyAll();
	}

	public synchronized void inviaCampione(int tipo,String id,int campione){
		long istante_richiesta = new Date().getTime();
		while (campioniDisponibili[tipo] == true){
			try{wait();}
			catch(InterruptedException e){e.printStackTrace();}
		}
		if ((new Date().getTime()-istante_richiesta) > 2000){
			System.out.println("Scartato campione del sensore: " + id );
		}
		else{
			System.out.println("Nuovo campione di tipo: " + tipo );		
			campioniDisponibili[tipo] = true;
			campioni[tipo] = campione;
		}
		notifyAll();
	}
}
