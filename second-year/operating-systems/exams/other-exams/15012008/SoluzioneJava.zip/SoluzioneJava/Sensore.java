public class Sensore extends Thread{	

	//0 : sensore di pressione
	//1 : sensore di temperatura
	//2 : sensore di umidita
	private int tipo; 

	private String id;
	private Stazione stazione;
	private int campione;

	public Sensore (int tipo, String id, Stazione stazione, int campione){
		this.id=id;
		this.stazione=stazione;
		this.campione=campione;
		this.tipo=tipo;
	}

	public void run (){
		stazione.inviaCampione(tipo,id, campione);
	}
}
