
public class Launcher {

	public static void main(String[] args){
		
		Stazione stazione = new Stazione();
		Sensore s1 = new Sensore (0, "Sensore1", stazione, 760);
		Sensore s2 = new Sensore (1, "Sensore2", stazione, 20);
		Sensore s3 = new Sensore (2, "Sensore3", stazione, 60);

		Sensore s4 = new Sensore (0, "Sensore4", stazione, 762);
		Sensore s5 = new Sensore (1, "Sensore5", stazione, 19);
		Sensore s6 = new Sensore (2, "Sensore6", stazione, 62);

		Sensore s7 = new Sensore (0, "Sensore7", stazione, 761);
		Sensore s8 = new Sensore (1, "Sensore8", stazione, 21);
		Sensore s9 = new Sensore (2, "Sensore9", stazione, 59);

		Meteorologo m1 = new Meteorologo (2500, stazione );
		Meteorologo m2 = new Meteorologo (2500, stazione );

		m1.start();
		m2.start();
		s1.start();
		s4.start();
		s2.start();
		s3.start();
		s5.start();
		s6.start();
		try{Thread.sleep(3000);}catch(InterruptedException e){}
		s8.start();
		s7.start();
		s9.start();




	}

}
