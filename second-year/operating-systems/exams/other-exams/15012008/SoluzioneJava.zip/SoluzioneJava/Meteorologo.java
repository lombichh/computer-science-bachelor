public class Meteorologo extends Thread{

	private Stazione stazione;
	private int durataElaborazione;

	public Meteorologo (int durataElaborazione, Stazione stazione ){
		this.stazione=stazione;
		this.durataElaborazione = durataElaborazione;
	}

	public void run (){
		stazione.generaBollettino(durataElaborazione);
	}
}
