#!/bin/sh

if test $# -lt 1
then    
   echo "usage:$0 <targetDir1> ... <targetDirN>"    
   exit 1
fi

for i in $*
do
	case $i in    
	/*) ;;    
	*)  echo "$i is not an absolute directory"        	
	    exit 2;;
	esac
	if ! test -d "$i"
	then    
		echo "$i is not a valid directory"
		exit 3
	fi

done

oldpath=$PATH
PATH=$PATH:`pwd`

for i in $*
do
   findDifferentUser_rec.sh `stat --format=%U "$i"` "$i"
   result=$?
   echo "$i : trovati $result file con owner diverso da "`stat --format=%U "$i"`
done
PATH=$oldpath
