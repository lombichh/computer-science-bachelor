#!/bin/sh
#$1: utente cartella iniziale
#$2: cartella sulla quale andare in ricorsione

cd "$2" 
count=0
for f in *
do
	if test -d "$f"; then
		$0 "$1" "$2"/"$f"
		result=$?
		count=`expr $count + $result`
	elif test -f "$f"; then 
		if test "$1" != `stat --format=%U "$f"`; then
			echo "$f user: "`stat --format=%U "$f"` 
			count=`expr $count + 1`
		fi
	fi

done
exit $count
