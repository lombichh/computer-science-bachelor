#!/bin/sh

counter=0
if test $# -lt 2
then
    echo "usage: esplora <dir1>  ... <dirN> <parola>"
    exit 1
fi	

parola=$1
shift

for i in $*
do
  if ! test -d "$i"
  then
		echo "Argomento non direttorio" $i
		exit 1
  fi
  case "$i" in 
		/*);;
		*) echo "Direttorio non assoluto" $i
		   exit 1;;
  esac
done

oldpath=$PATH
PATH=$PATH:`pwd`
counter=0

for i in $*
do
	esplora_rec.sh "$i" $parola
done
PATH=$oldpath

if ! test -f $HOME/trovati.txt
then
	echo "Nessun direttorio trovato"
else
    cat $HOME/trovati.txt
fi
	
