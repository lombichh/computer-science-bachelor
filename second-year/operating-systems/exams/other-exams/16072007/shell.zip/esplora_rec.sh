#!/bin/sh

cd "$1"
trovato=0
contatore=0

for i in  *
do
   if test -h "$i" 
   then
	continue
   fi
   if test -f "$i"
   then
	word=`head -1 "$i" | cut -d ' ' -f 1`
	case "$word" in 
		$2) trovato=1;;
		*);;
	esac
	if [ $trovato -eq 1 ]
	then
		contatore=`expr $contatore + 1`
	fi
	continue
   fi		
   if test -d "$i"
   then
	$0 "$i" "$2"
   fi  	 	
done

if test $contatore -gt 0 
then
   echo `pwd` >>$HOME/trovati.txt	
fi
