import java.util.ArrayList;
import java.util.Collections;
public class AulaEsami{

private int current_queue=0;  //Numero di thread che sono in coda
private int postazione_corrente=0;
private int out_service=1;
public boolean exam=false;
private ArrayList list;
private static final int NMAX=10;

	public AulaEsami(){
		list = new ArrayList();	
	}

	public synchronized void forza_inizio_esame(){
		exam = true;//inizio dell'esame
		notifyAll();
	}

	public synchronized int entra(String nome){

		current_queue++;
		list.add(nome);
		Collections.sort(list);
		if (current_queue >= NMAX)
			exam=true;
		notifyAll();//abbiamo appena modificato lo stato, sblocchiamo tutti i thread eventualmente in attesa
		try{
			while(!exam ||(!((String)list.get(0)).equals(nome)) ){ //Attesa del proprio turno
				wait();
				}
			} catch(InterruptedException e){}
		postazione_corrente++;
		list.remove(nome);
		int mia_postazione = postazione_corrente;
		notifyAll();
		return mia_postazione;
		
	}
	
	public synchronized void terminaEsame(String nome, int mia_postazione){  //Fine dell'esame

		while(out_service != mia_postazione){
		try{
			wait();	}
		catch(InterruptedException e){}	
		}
	    	out_service++;
		System.out.println("Studente "+nome+" ha sostenuto l'esame nella postazione "+mia_postazione);
		notifyAll();
	
	}
}
