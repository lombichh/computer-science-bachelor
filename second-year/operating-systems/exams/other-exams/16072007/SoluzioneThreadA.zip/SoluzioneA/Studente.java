public class Studente extends Thread{

	int MAX_EXAM_TIME = 3000;
	AulaEsami coda;
	String nome;

	public Studente(AulaEsami coda, String nome){
		this.nome=nome;
		this.coda=coda;
	}
	
	public void run(){
		int postazione = coda.entra(this.nome);
		try{Thread.sleep(MAX_EXAM_TIME);}catch(InterruptedException e){}
		coda.terminaEsame(this.nome,postazione);	
	}
}
