
public class Launcher {
public static int MAX_DELAY=4000;
public static void main(String[] args){

	if (args == null || args.length==0){
		System.out.println("Uso: java Launcher [true|false]\n dove true forza l'arrivo di PMAX thread, false forza l'arrivo di un numero di thread inferiore a PMAX.");
		return;
	}
	
	boolean pmax_threads = Boolean.parseBoolean(args[0]);

	AulaEsami coda=new AulaEsami();

	Studente s1=new Studente(coda,"Paperino");
	Studente s2=new Studente(coda,"Amelia");
	Studente s3=new Studente(coda,"NonnaPapera");
	Studente s4=new Studente(coda,"Qui");
	Studente s5=new Studente(coda,"Topolino");
	Studente s6=new Studente(coda,"ZioPaperone");
	Studente s7=new Studente(coda,"Macchianera");
	Studente s8=new Studente(coda,"ArchimedePitagorico");
	Studente s9=new Studente(coda,"Etabeta");
	Studente s10=new Studente(coda,"Gastone");

	
	s1.start();
	s2.start();
	s3.start();
	try{Thread.sleep(3000);}catch(InterruptedException e){}
	s4.start();
	s5.start();
	s6.start();
	s7.start();
	s8.start();
	if(pmax_threads){
		s9.start();
		s10.start();
	}
	System.out.println("Attesa di MAX_DELAY...");
	try{Thread.sleep(MAX_DELAY);}catch(InterruptedException e){}

	if(!coda.exam){
		System.out.println("Forza inizio esame");
		coda.forza_inizio_esame();
	}
}
}
