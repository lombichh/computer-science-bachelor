#!/bin/bash


# Schema di soluzione
# equilibra.sh
#	---> verificaDir.sh -->muoviFile.sh
#	---> stampa.sh

#verifica dei parametri
if test $# != 2
then
    echo "usage:$0 <dir1> <dir2>"
    exit 1
fi
dir1="$1"
case "$dir1" in
    /*) ;;
    *)  echo "$dir1 is not an absolute directory"
        exit 2;;
esac
if ! test -d "$dir1"
then
    echo "$dir1 is not a valid directory"
    exit 3
fi

dir2="$2"
case "$dir2" in
    /*) ;;
    *)  echo "$dir2 is not an absolute directory"
        exit 2;;
esac
if ! test -d "$dir2"
then
    echo "$dir2 is not a valid directory"
    exit 3
fi

PATH=$PATH:`pwd`
verificaDir.sh "$dir1" "$dir2"
stampa.sh "$dir1" 1

