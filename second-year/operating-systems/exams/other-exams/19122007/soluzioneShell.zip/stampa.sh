#!/bin/bash
#stampa

dir="$1"
level="$2"

echo ==========
echo Livello : $level '('"$dir"')'
echo Nomi dei 'file' : `ls -A "$dir"`
echo Conteggio : `ls -A "$dir" | wc -w`
echo

cd "$dir"
for f in *
do
    if test -d "$f"
    then
        "$0" "$f" `expr $level + 1`
    else
        continue			 
fi
done
exit 0
