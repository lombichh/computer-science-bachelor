#!/bin/bash
dir1="$1"
dir2="$2"

count1=`ls -RA "$dir1" | wc -w`
count2=`ls -RA "$dir2" | wc -w`

echo $1: $count1
echo $2: $count2
echo differenza: `expr $count1 - $count2`
PATH=$PATH:`pwd`
if test `expr $count1 - $count2` -ge 0 -a `expr $count1 - $count2` -le 1
	then 
	echo dirMaggiore: "$dirMaggiore" "$count1"
	echo dirMinore: "$dirMinore" "$count2"
	echo Nuovo contenuto dir1: "$dir1"
        exit 0
elif test `expr $count1 - $count2` -gt 1
	then 
	dirMaggiore="$dir1"
	dirMinore="$dir2"
	muoviFile.sh "$dirMaggiore" "$dirMinore"
	"$0" "$dirMaggiore" "$dirMinore"
else
	dirMaggiore="$dir2"
	dirMinore="$dir1"
	muoviFile.sh "$dirMaggiore" "$dirMinore"
	"$0" "$dirMaggiore" "$dirMinore"
fi
