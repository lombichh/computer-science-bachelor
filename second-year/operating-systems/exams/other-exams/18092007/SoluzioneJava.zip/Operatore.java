public class Operatore extends Thread{

	private Officina officina;
	//fase è un intero da 0 a 3 che indica quale tipo di fase di revisione è associata all'oggetto Operatore corrente
	private int fase;

	public Operatore (int fase, Officina officina ){
		this.fase=fase;
		this.officina=officina;
	}

	public void run (){
		officina.effettuaRevisione(fase);
	}
}
