import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Random;
public class Officina{
	
	private int currentstep = 0;
	private final static int MAX_STEPS = 4;
	private String scheda_autovettura;
	private boolean available = false;

	public synchronized void richiediRevisione(String autovettura){
		while (available == true){
			try{wait();}
			catch(InterruptedException e){e.printStackTrace();}
		}
		this.scheda_autovettura = autovettura;
		System.out.println("Nuova autovettura: "+this.scheda_autovettura);
		available = true;
		notifyAll();
	}
	
	public synchronized void effettuaRevisione(int step){
		Random r = new Random();
		while (available == false || currentstep != step){
			try{wait();}
			catch(InterruptedException e){e.printStackTrace();}
		}

		if (currentstep == 0){
			Date now = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("HH-mm-ss");
			this.scheda_autovettura = scheda_autovettura +"\n"+"Accettazione vettura effettuata alle ore : "+sdf.format(now);

		}
		else if (currentstep == 1){
			int durata = r.nextInt(100) ;
			this.scheda_autovettura = scheda_autovettura +"\n"+"Lavaggio vettura – durata: "+durata+" minuti";
		}
		else if (currentstep == 2){
			int durata = r.nextInt(100) ;
			this.scheda_autovettura = scheda_autovettura +"\n"+"Messa a punto – durata: "+durata+" minuti";
		}

		else if (currentstep+1 == MAX_STEPS ){
			int spesa = r.nextInt(100) ;
			this.scheda_autovettura = scheda_autovettura +"\n"+"Fatturazione – Totale: "+spesa+" euro";
			available = false;
			System.out.println("Termine revisione autovettura:\n***********\n"+this.scheda_autovettura+"\n*********\n");
			this.scheda_autovettura = null;
		}
		currentstep = (currentstep + 1 ) % MAX_STEPS;
		notifyAll();
	}
}
