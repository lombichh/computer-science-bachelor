public class Cliente extends Thread{	
	private String autovettura;
	private Officina officina;

	public Cliente (String autovettura, Officina officina ){
		this.autovettura=autovettura;
		this.officina=officina;
	}

	public void run (){
		officina.richiediRevisione(autovettura);
	}

}
