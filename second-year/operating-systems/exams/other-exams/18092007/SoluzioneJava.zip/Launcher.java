
public class Launcher {

	public static void main(String[] args){
		
		Officina officina = new Officina();
		Cliente c1 = new Cliente("Prima autovettura",officina);
		Cliente c2 = new Cliente("Seconda autovettura",officina);
		Cliente c3 = new Cliente("Terza autovettura",officina);
		Operatore o1 = new Operatore(0, officina );
		Operatore o2 = new Operatore(1, officina );
		Operatore o3 = new Operatore(2, officina );
		Operatore o4 = new Operatore(3, officina );
		Operatore o5 = new Operatore(0, officina );
		Operatore o6 = new Operatore(1, officina );
		Operatore o7 = new Operatore(2, officina );
		Operatore o8 = new Operatore(3, officina );
		Operatore o9 = new Operatore(0, officina );
		Operatore o10 = new Operatore(1, officina );
		Operatore o11 = new Operatore(2, officina );
		Operatore o12 = new Operatore(3, officina );

		c1.start();

		o1.start();
		o6.start();
		o4.start();
		o5.start();
		try{Thread.sleep(3000);}catch(InterruptedException e){}
		c2.start();
		o7.start();
		o2.start();
		o10.start();
		o11.start();
		o12.start();
		o9.start();
		o3.start();
		o8.start();
		c3.start();




	}

}
