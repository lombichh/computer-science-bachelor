
public class Main {

	public static void main(String[] args) {
		Risorsa r = new Risorsa();
		Macchina1 m1 = new Macchina1(r);
		Macchina2 m2 = new Macchina2(r);
		Macchina3 m3 = new Macchina3(r);
		
		m1.start();
		m2.start();
		try {
			Thread.sleep(15000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		m3.start();
	}
	
}

