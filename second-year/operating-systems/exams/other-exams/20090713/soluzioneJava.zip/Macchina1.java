
public class Macchina1 extends Thread{

	
	Risorsa r;

	public Macchina1 (Risorsa r){
		this.r=r;
	}

	public void run(){
		try{
			System.out.println("Produzione cioccolatini al latte... ");
			while(true){
				r.aggiungiLatte();
				sleep(100);
			}

		}
		catch (InterruptedException e ){}
	}

}