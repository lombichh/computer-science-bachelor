
public class Macchina2 extends Thread{

	
	Risorsa r;

	public Macchina2 (Risorsa r){
		this.r=r;
	}

	public void run(){
		try{
			System.out.println("Produzione cioccolatini fondenti... ");
			while(true){
				r.aggiungiFondente();
				sleep(100);
			}

		}
		catch (InterruptedException e ){}
	}

}