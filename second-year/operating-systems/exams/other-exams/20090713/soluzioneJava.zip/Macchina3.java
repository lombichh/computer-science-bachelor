
public class Macchina3 extends Thread{

	
	Risorsa r;

	public Macchina3 (Risorsa r){
		this.r=r;
	}

	public void run(){
		try{
			System.out.println("Confezionamento scatole... ");
			while(true){
				r.confezionaScatola();
				sleep(100);
			}

		}
		catch (InterruptedException e ){}
	}

}