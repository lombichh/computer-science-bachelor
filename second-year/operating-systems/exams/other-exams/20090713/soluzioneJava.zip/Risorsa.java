
public class Risorsa {
	Semaforo sM,sC1,sC2,sScatola;
	public final int MAX = 90;
	
	int c1, c2;
	public Risorsa() {
		sM = new Semaforo(1);
		sScatola = new Semaforo(0);
		sC1 = new Semaforo(MAX);
		sC2 = new Semaforo(MAX);
		c1 = 0; c2=0;
	}

	public void aggiungiLatte() {
		
		sC1.p();
		sM.p();
		c1++;
		//Attenzione alla condizione: devo mandare sempre un solo sScatola.v();  
		if ( (c1==40 ) && (c2>=40 ) )
			sScatola.v();
		
		sM.v();
		System.out.println("C1, c2 ["+c1+","+c2+"]");
		
	}

	public void aggiungiFondente() {
		
		sC2.p();
		sM.p();
		c2++;
		if ( (c1>=40 ) && (c2==40 ) )
			sScatola.v();
		
		sM.v();
		System.out.println("C1, c2 ["+c1+","+c2+"]");
	}

	public void confezionaScatola() {
		
		sScatola.p();
		sM.p();
		c1= c1-40;
		c2= c2-40;
		
		//Lascio la possibilità di continuare a inscatolare solo 
		//se ci sono ancora cioccolatini sufficienti di entrambi i tipi 
		if ( (c1>=40 ) && (c2>=40 ) )
			sScatola.v();
		
		for (int i = 0; i<40; i++){
			sC1.v();
			sC2.v();
		}
		
		System.out.println("Confezionata scatola!");
		System.out.println("Rimanenti: C1, c2 ["+c1+","+c2+"]");
		sM.v();
		
		
	}

}
