#!/bin/sh
cd "$1"

livello=`pwd | grep  '/' -o | wc -l`
echo "Livello della gerarchia del file system:$livello" > $2

for f in *
do
	if test -d "$f"
		then
		$0 "$f" "$2"
	fi
done
