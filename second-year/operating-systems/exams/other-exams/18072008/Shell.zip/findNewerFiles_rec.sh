#!/bin/sh
#$1: cartella nella quale andare in ricorsione 
#$2: nome assoluto file di report
#$3: anno
#$4: mese
#$5: giorno
cd "$1" 


for f in *
do    
	if test -h "$f" #se il file corrente e' un link
	then        
	 	continue

	elif test -d "$f"
   	then        
	 	$0 $1/"$f" $2 $3 $4 $5
	elif test -f "$f"
	then
		anno=`stat --format=%z "$f" | cut -d ' ' -f 1 | cut -d '-' -f1`
		mese=`stat --format=%z "$f" | cut -d ' ' -f 1 | cut -d '-' -f2`
		giorno=`stat --format=%z "$f" | cut -d ' ' -f 1 | cut -d '-' -f3`
		if test $anno -gt $3; then
			echo anno_$anno - `pwd`/"$f">> $2
		elif test $mese -gt $4 -a $anno -eq $3; then
			echo mese_$mese - `pwd`/"$f">> $2
		elif test $mese -eq $4 -a $anno -eq $3 -a $giorno -gt -$5; then
			echo giorno_$giorno - `pwd`/"$f">> $2
		fi
	fi	
done

