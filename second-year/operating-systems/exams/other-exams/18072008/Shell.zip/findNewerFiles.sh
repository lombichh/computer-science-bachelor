#!/bin/sh

if test $# -ne 3
then    
   echo "usage:$0 <scrDir> <reportFile> <yyyy-mm-dd>"    
   exit 1
fi

case $1 in    
/*) ;;    
*)  echo "$1 is not an absolute directory"        	
    exit 4;;
esac

if ! test -d "$1"
then    
echo "$1 is not a valid directory"
exit 5
fi

case $2 in    
/*) ;;    
*)  echo "$2 is not an absolute file"
    exit 4;;
esac

case $3 in    
????-??-??) ;;    
*)  echo "Date $3 should have the format \"yyyy-mm-dd\""
    exit 4;;
esac

anno=`echo $3 | cut -d ' ' -f 1 | cut -d '-' -f1`
mese=`echo $3 | cut -d ' ' -f 1 | cut -d '-' -f2`
giorno=`echo $3 | cut -d ' ' -f 1 | cut -d '-' -f3`

oldpath=$PATH
PATH=$PATH:`pwd`
   findNewerFiles_rec.sh $1 $2 $anno $mese $giorno
PATH=$oldpath

