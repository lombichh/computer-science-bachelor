public class Allarme extends Thread {
	public static final int N = 5;
	public static final int T = 2000;
	Centralina centralina;

	public Allarme(Centralina centralina){
		this.centralina=centralina;
	}
	
	public void run(){
		for (int i = 0; i< N;i++){
			try{Thread.sleep(T);}catch(InterruptedException e){}
			centralina.forzaReport();
		}
	}
}
