import java.util.Date;
public class Centralina{

	public static final int N = 3;

	boolean forzaReport = false;
	int campioniDisponibili[] = new int[]{0,0,0,0}; //l'indice rappresenta il tipo di campione cui si sta facendo riferimento

	//Array di array di campioni
	//l'indice dell'array esterno rappresenta il tipo di campione cui si sta facendo riferimento
	int [][] campioni = new int[4][N]; 

	public synchronized void generaReport (){
		while ( !forzaReport && ! (campioniDisponibili[0] == N && campioniDisponibili[1] == N && campioniDisponibili[2] == N   && campioniDisponibili[3] == N  )  ) {
			try{wait();}
			catch(InterruptedException e){e.printStackTrace();}
		}

		System.out.println("******************************");
		if (forzaReport)
			System.out.println("Report sicurezza PARZIALE :");
		else
			System.out.println("Report sicurezza :");

		System.out.println("Velocità : " + determinaMedia(0));
		System.out.println("Imbardata : " + determinaMedia(1));
		System.out.println("Rollio : " + determinaMedia(2));
		System.out.println("Beccheggio : " + determinaMedia(3));

		campioniDisponibili=new int[]{0,0,0,0};
		campioni=new int[4][N];
		forzaReport = false;
		notifyAll();
	}

	public synchronized void inviaCampione(int tipo,String id,int campione){
		long istante_richiesta = new Date().getTime();
		while (campioniDisponibili[tipo] == N){
			try{wait();}
			catch(InterruptedException e){e.printStackTrace();}
		}

		System.out.println("Nuovo campione di tipo: " + tipo );		

		campioni[tipo][campioniDisponibili[tipo]] = campione;
		campioniDisponibili[tipo] ++;

		notifyAll();
	}

	public synchronized void forzaReport(){
		forzaReport = true;
		notifyAll();
	}

	private double determinaMedia(int tipo){
		if (campioniDisponibili[tipo] == 0)
			return 0;
		int totale = 0;
		for (int i=0; i< campioniDisponibili[tipo]; i++){
			totale += campioni[tipo][i];
		}
		return 	totale / campioniDisponibili[tipo];
	}
}
