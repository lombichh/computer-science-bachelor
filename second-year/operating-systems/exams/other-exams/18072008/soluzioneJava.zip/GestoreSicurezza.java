public class GestoreSicurezza extends Thread{

	private Centralina centralina;

	public GestoreSicurezza (Centralina centralina ){
		this.centralina=centralina;
	}

	public void run (){
		centralina.generaReport();
	}
}
