public class Launcher {

	public static void main(String[] args){
		
		Centralina centralina = new Centralina();
		Sensore s1 = new Sensore (0, "Sensore1", centralina, 760);
		Sensore s2 = new Sensore (1, "Sensore2", centralina, 20);
		Sensore s3 = new Sensore (2, "Sensore3", centralina, 60);

		Sensore s4 = new Sensore (0, "Sensore4", centralina, 762);
		Sensore s5 = new Sensore (1, "Sensore5", centralina, 19);
		Sensore s6 = new Sensore (2, "Sensore6", centralina, 62);

		Sensore s7 = new Sensore (0, "Sensore7", centralina, 761);
		Sensore s8 = new Sensore (1, "Sensore8", centralina, 21);
		Sensore s9 = new Sensore (2, "Sensore9", centralina, 59);

		Sensore s10 = new Sensore (3, "Sensore10", centralina, 7);
		Sensore s11 = new Sensore (3, "Sensore11", centralina, 5);
		Sensore s12 = new Sensore (3, "Sensore12", centralina, 9);

		Sensore s13 = new Sensore (0, "Sensore13", centralina, 800);
		Sensore s14 = new Sensore (1, "Sensore14", centralina, 19);
		Sensore s15 = new Sensore (2, "Sensore15", centralina, 62);
		Sensore s16 = new Sensore (3, "Sensore16", centralina, 9);

		GestoreSicurezza m1 = new GestoreSicurezza (centralina );
		GestoreSicurezza m2 = new GestoreSicurezza (centralina );
		GestoreSicurezza m3 = new GestoreSicurezza (centralina );

		Allarme a = new Allarme (centralina );

		a.start();
		m1.start();
		m2.start();
		m3.start();
		s1.start();
		s4.start();
		s2.start();
		s3.start();
		s5.start();
		s6.start();
		try{Thread.sleep(4000);}catch(InterruptedException e){}
		s8.start();
		s7.start();
		s9.start();
		s10.start();
		s11.start();
		s12.start();
		s13.start();
		s14.start();
		s15.start();
		s16.start();



	}

}
