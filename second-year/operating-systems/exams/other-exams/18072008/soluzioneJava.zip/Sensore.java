public class Sensore extends Thread{	

	//0 : sensore di velocita
	//1 : sensore di imbardata
	//2 : sensore di rollio
	//3 : sensore di beccheggio
	private int tipo; 

	private String id;
	private Centralina centralina;
	private int campione;

	public Sensore (int tipo, String id, Centralina centralina, int campione){
		this.id=id;
		this.centralina=centralina;
		this.campione=campione;
		this.tipo=tipo;
	}

	public void run (){
		centralina.inviaCampione(tipo,id, campione);
	}
}
